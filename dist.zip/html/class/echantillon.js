"use strict";
/**
 * HTML Print for API.
 *
 * @copyright 2026-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.Echantillon = void 0;
const constant_1 = require("../../constant");
const core_1 = require("./core");
/**
 * Print Class for HTML View
 */
class Echantillon extends core_1.CoreHtmlView {
    datas;
    constructor() {
        super();
        this.createEchantillonHtmlString();
    }
    createEchantillonHtmlString() {
        this._HTMLResult = ['<!DOCTYPE html>',
            '<html lang="en">',
            '<head>',
            '    <meta charset="UTF-8">',
            '    <meta name="viewport" content="width=device-width, initial-scale=1.0">',
            '    <title>Configuration</title>',
            this.getFile("./css/form/configuration.css"),
            this.getFile("./css/form/main.css"),
            this.getFile("./css/main.css"),
            this.getFile("./css/modal.css"),
            this.getFile("./css/editingList.css"),
            this.getFile("./css/splitter.css"),
            '</head>',
            '<body>',
            '<div class="content" id="passeportsContent"></div>',
            '</body> ',
            `<script nonce="${constant_1._NONCE}">`,
            `_DATAPI = ${JSON.stringify(this.datas)}`,
            '</script>',
            `<script nonce="${constant_1._NONCE}" src="./js/constants.js"></script>`,
            `<script nonce="${constant_1._NONCE}" src="./js/api/print.js"></script>`,
            `<script nonce="${constant_1._NONCE}">start()</script>`,
            '</html>'].map((e) => e.trim());
    }
    toString() {
        return super.toString();
    }
}
exports.Echantillon = Echantillon;
