"use strict";
/**
 * HTML Views First for API.
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.List = void 0;
const constant_1 = require("../../constant");
const base_1 = require("../../db/base");
const core_1 = require("./core");
class List extends core_1.CoreHtmlView {
    constructor(name, excel) {
        super();
        this.createIndexHtmlString(name, excel);
    }
    createIndexHtmlString(name, excel) {
        const listCols = [];
        const src = base_1.dataBase[name];
        Object.keys(src.columns).filter((e) => src.columns[e].list === true).forEach(e => {
            listCols.push({
                key: e,
                title: src.columns[e].title,
                searchType: src.columns[e].searchType || "text"
            });
        });
        this._HTMLResult = `
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestion des ${name}s</title>
    <link rel="stylesheet" href="${constant_1._LOCALHOST}/css/bootstrap.css">
    <link rel="stylesheet" href="${constant_1._LOCALHOST}/css/icons.css">
    <link rel="stylesheet" href="${constant_1._LOCALHOST}/css/context-menu.css">
    ${excel ? `<link rel="stylesheet" href="${constant_1._LOCALHOST}/css/import.css">` : ''}
    <link rel="stylesheet" href="${constant_1._LOCALHOST}/css/modal.css">
    <link rel="stylesheet" href="${constant_1._LOCALHOST}/css/splitter.css">
    <link rel="stylesheet" href="${constant_1._LOCALHOST}/css/menu.css">
</head>

<body>
	<header id="splitter-nav-site" class="splitter-nav-site"></header>
    <main class="main-view">
        <div class="splitter-nav-view" id="left-pane">
        </div>
        <div class="v-drag" id="separator"></div>
        <div class="content" id="right-pane">
			<div class="card">
				<div class="card-header row">
					<div class="col-12">
						<div class="input-group">
							<span class="input-group-text" id="infos"></span>
							<a class="btn btn-warning" id="raz">RAZ</a>
							<span class="input-group-text" id="nameType">${name}</span>
							${src.create === true ? ` <button class="btn btn-primary icon_plus btn-sm" id="ajouter" href="${constant_1._LOCALHOST}/${src.singular}-add.html"></button> ` : ''}
                            ${excel ? `
							<span class="input-group-text"></span>
							<div class="btn btn-success field" id="blockImporter">
                            	<input type="file" name="file" id="fileone" class="inputfile inputfile-1" accept=".xls,.xlsx"
                                data-multiple-caption="{count} files selected" multiple />
                            	<label id="fileonelabel" for="fileone" class="icon_bottom"> Importer excel</label>
							</div>` : ''}
							<span class="input-group-text" id="globalSearchIcon">🔎 Cherche</span>
							<input id="globalSearch" type="text" class="form-control" placeholder="Recherche dans tous les champs">
							<button class="btn btn-success icon_up btn-sm" id="exportExcel"> Excel</button>  
						</div>
					</div>
				</div>
				<div class="table-responsive">
					<form id="actionForm" class="formData" enctype="multipart/form-data" method="POST">
						<table id="jsonTable" class="table table-striped table-hover">
						<thead></thead>
						<tbody></tbody>
						<tfoot></tfoot>
						</table>
					</form>
				</div>
				<div class="card-footer row">
					<div class="col-1">
						<span class="input-group-text">Par page</span>
					</div>
					<div class="col-1">
						<div class="input-group">
							<select id="perPageSelect" class="form-control">
								<option selected>25</option>
								<option >50</option>
								<option>100</option>
								<option>250</option>
								<option>500</option>
							</select>
						</div>
					</div>				
					<div class="col-10">
						<nav>
							<ul id="pagination" class="pagination justify-content-end"></ul>
						</nav>
					</div>
				</div>
			</div>
        </div>
		
		<div class="context-menu">
			<ul id="contextMenu" class="context-menu-options">
			</ul>
		</div>

	<div id="modal"></div>  
    </main>
</body> 
<script src="${constant_1._LOCALHOST}/js/api.js"></script>
<script>const structure = ${JSON.stringify(listCols)}</script>
<script src="${constant_1._LOCALHOST}/js/configuration.js"></script>
<script src="${constant_1._LOCALHOST}/js/constants.js"></script>
<script src="${constant_1._LOCALHOST}/js/all.js"></script>
<script src="${constant_1._LOCALHOST}/js/common/modal.js"></script>
<script src="${constant_1._LOCALHOST}/js/common/splitter.js"></script>
<script src="${constant_1._LOCALHOST}/js/common/menu.js"></script>  
<script src="${constant_1._LOCALHOST}/js/dataTables.js"></script>
<script src="${constant_1._LOCALHOST}/js/${name}/list.js"></script>  
<script src="${constant_1._LOCALHOST}/js/form.js"></script>

${excel ? `<script src="${constant_1._LOCALHOST}/js/libs/xlsx.full.min.js"></script>` : ''}
</html>
`.split(constant_1.EConstant.newline)
            .map((e) => e.trim())
            .filter((e) => e.trim() != "");
    }
    toString() {
        return super.toString();
    }
}
exports.List = List;
