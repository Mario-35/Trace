"use strict";
/**
 * HTML Print for API.
 *
 * @copyright 2026-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.Export = void 0;
const constant_1 = require("../../constant");
const core_1 = require("./core");
/**
 * Print Class for HTML View
 */
class Export extends core_1.CoreHtmlView {
    datas;
    constructor(datas) {
        super();
        this.datas = datas;
        this.createExportHtmlString();
    }
    createExportHtmlString() {
        this._HTMLResult = ['<!DOCTYPE html>',
            '<html lang="en">',
            '<head>',
            '    <meta charset="UTF-8">',
            '    <meta name="viewport" content="width=device-width, initial-scale=1.0">',
            '    <title>Configuration</title>',
            this.getFile("./css/form/configuration.css"),
            this.getFile("./css/form/main.css"),
            this.getFile("./css/main.css"),
            '</head>',
            '<body>',
            '<div class="content" id="passeportsContent"></div>',
            '</body> ',
            `<script>`,
            `const _DATAS = ${JSON.stringify(this.datas)}`,
            '</script>',
            `<script src="${constant_1._LOCALHOST}/js/libs/xlsx.full.min.js"></script>`,
            `<script src="${constant_1._LOCALHOST}/js/export.js"></script>`,
            '</html>'].map((e) => e.trim());
    }
    toString() {
        return super.toString();
    }
}
exports.Export = Export;
