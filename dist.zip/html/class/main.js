"use strict";
/**
 * HTML Views First for API.
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Index = void 0;
const constant_1 = require("../../constant");
const core_1 = require("./core");
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
/**
 * Query Class for HTML View
 */
class Index extends core_1.CoreHtmlView {
    constructor() {
        super();
        this.createIndexHtmlString();
    }
    createIndexHtmlString() {
        // Split files for better search and replace
        this._HTMLResult = fs_1.default
            .readFileSync(path_1.default.resolve(__dirname, "../../public/", "index.html"))
            .toString()
            .split(constant_1.EConstant.newline)
            .map((e) => e.trim())
            .filter((e) => e.trim() != "");
        this.replacer('"@DATAS@"', 'console.log("15-02-2026")');
        this.replaceFile("css/splitter.css");
        this.replaceFile("css/bootstrap.css");
        this.replaceFile("js/constants.js");
        this.replaceFile("js/common/splitter.js");
        this.replaceFile("js/common/menu.js");
    }
    toString() {
        return super.toString();
    }
}
exports.Index = Index;
