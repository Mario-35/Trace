"use strict";
/**
 * HTML Views First for API.
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Configuration = void 0;
const constant_1 = require("../../constant");
const base_1 = require("../../db/base");
const core_1 = require("./core");
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
/**
 * Query Class for HTML View
 */
class Configuration extends core_1.CoreHtmlView {
    constructor() {
        super();
        this.createConfigurationHtmlString();
    }
    createConfigurationHtmlString() {
        // Split files for better search and replace
        this._HTMLResult = fs_1.default
            .readFileSync(path_1.default.resolve(__dirname, "../../public/", "addConfiguration.html"))
            .toString()
            .split(constant_1.EConstant.newline)
            .map((e) => e.trim())
            .filter((e) => e.trim() != "");
        this.replacer('"@DATAS@"', `
            const excelColumns = ["${Object.keys(base_1.dataBase.echantillons.columns).filter(e => base_1.dataBase.echantillons.columns[e].excel).join('","')}"];
            const stickerElements = {${Object.keys(base_1.dataBase.echantillons.columns).filter(e => base_1.dataBase.echantillons.columns[e].etiquette).map(e => `"${e}" : "${base_1.dataBase.echantillons.columns[e].etiquette}"`)}};
            `);
        this.replaceFile("css/form/configuration.css");
        this.replaceFile("css/form/main.css");
        this.replaceFile("css/main.css");
        this.replaceFile("css/editingList.css");
        this.replaceFile("css/splitter.css");
        this.replaceFile("css/modal.css");
        // LOAD or file 
        this.replaceFile("js/configuration.js");
        this.replaceFile("js/constants.js");
        this.replaceFile("js/all.js");
        this.replaceFile("js/common/splitter.js");
        this.replaceFile("js/common/menu.js");
        this.replaceFile("js/common/editingList.js");
        this.replaceFile("js/form.js");
        this.replaceFile("js/api.js");
        this.replaceFile("js/helper.js");
        this.replaceFile("js/common/modal.js");
        this.replaceFile("js/libs/JsBarcode.all.min.js");
        this.replaceFile("js/api/print.js");
        this.replaceFile("js/configurations/add.js");
        this.replaceFile("js/common/regions.js");
        this.replaceFile("js/configurations/event.js");
        this.replaceFile("js/stickers/controller.js");
        this.replaceFile("js/configurations/controller.js");
    }
    toString() {
        return super.toString();
    }
}
exports.Configuration = Configuration;
