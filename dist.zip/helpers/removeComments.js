"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.removeComments = removeComments;
function removeComments(input) {
    // Takes a string of code, not an actual function.
    return input.replace(/\/\*[\s\S]*?\*\/|(?<=[^:])\/\/.*|^\/\/.*/g, "").trim();
}
