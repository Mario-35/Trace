"use strict";
/**
 * Clean DB routes
 *
 * @copyright 2026-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.clean = clean;
const db_1 = require("../db");
async function clean() {
    await (0, db_1.executeSql)([
        `DELETE FROM "echantillons" WHERE etat = 'Supprimer'`,
        `DELETE FROM "sites" WHERE UPPER(nom) = 'SUPPRIMER'`,
    ]).then(() => {
        return true;
    });
}
