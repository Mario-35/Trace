"use strict";
/**
 * Clean DB routes
 *
 * @copyright 2026-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.clean = clean;
const controller_1 = require("../controller");
const db_1 = require("../db");
const base_1 = require("../db/base");
const accentsTidy = function (s) {
    var r = s.toLowerCase();
    const non_asciis = { 'a': '[àáâãäå]', 'ae': 'æ', 'c': 'ç', 'e': '[èéêë]', 'i': '[ìíîï]', 'n': 'ñ', 'o': '[òóôõö]', 'oe': 'œ', 'u': '[ùúûűü]', 'y': '[ýÿ]' };
    for (const i in non_asciis) {
        r = r.replace(new RegExp(non_asciis[i], 'g'), i);
    }
    return r;
};
async function clean() {
    const queries = [`DELETE FROM "echantillons" WHERE UPPER(unaccent(etat)) LIKE'SUPPRIM%'`,];
    return (0, controller_1.readId)(base_1.dataBase.configuration.name, 1)
        .then(async (configuration) => {
        configuration[0].etats[0].split(",").forEach((e) => {
            queries.push(`UPDATE echantillons SET etat = '${e}' WHERE UPPER(unaccent(etat)) LIKE '${accentsTidy(e).toLocaleUpperCase().slice(0, -1)}%'`);
        });
        queries.push(`UPDATE echantillons SET Region = (SELECT Region FROM sites WHERE sites.latitude = latitude AND sites.longitude = longitude limit 1) WHERE Region = 'Region'`);
        console.log(queries);
        return await (0, db_1.executeSql)(queries).then(() => { return true; });
    })
        .catch((error) => {
        console.error(error);
    });
}
