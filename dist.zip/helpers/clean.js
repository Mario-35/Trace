"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.clean = clean;
const db_1 = require("../db");
async function clean() {
    await (0, db_1.executeSql)(`DELETE FROM "echantillons" WHERE etat = 'Supprimer'`).then(() => {
        return true;
    });
}
