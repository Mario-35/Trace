"use strict";
/**
 * Clean DB routes
 *
 * @copyright 2026-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.clean = clean;
const db_1 = require("../db");
async function clean() {
    await (0, db_1.executeSql)([
        `DELETE FROM "echantillons" WHERE UPPER(etat) = 'SUPPRIME'`,
        `DELETE FROM "sites" WHERE UPPER(nom) = 'SUPPRIMER'`,
        `UPDATE echantillons SET etat = 'Crée' WHERE etat = 'Créer'`,
        `UPDATE echantillons SET Region = (SELECT Region FROM sites WHERE sites.latitude = latitude AND sites.longitude = longitude limit 1) WHERE Region = 'Region'`
    ]).then(() => {
        return true;
    });
}
