"use strict";
/**
 * asyncForEach.
 *
 * @copyright 2026-present Inrae
 * @author mario.adam@inrae.fr
 *
 * https://gist.github.com/Atinux/fd2bcce63e44a7d3addddc166ce93fb2
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.asyncForEach = asyncForEach;
/**
 *
 * @param array for loop
 * @param callback fn to execute in loop
 */
async function asyncForEach(array, callback) {
    if (array)
        for (let index = 0; index < array.length; index++) {
            // ATTENTION AWAIT Before callback is important (it send error BUT IS NOT)
            await callback(array[index], index, array);
        }
}
