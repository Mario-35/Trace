"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.removeReturns = removeReturns;
const constant_1 = require("../constant");
function removeReturns(input) {
    return input
        .replace(/\r\n/g, constant_1.EConstant.return)
        .split(constant_1.EConstant.return)
        .map((e) => e.trim())
        .filter((e) => e.trim() != "")
        .join(" ");
}
