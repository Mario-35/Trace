"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.download = download;
const db_1 = require("../db");
const base_1 = require("../db/base");
var fs = require('fs');
var path = require('path');
var AdmZip = require("adm-zip");
async function asJson(tableName) {
    return (0, db_1.executeSql)(`SELECT COALESCE( JSON_AGG(t), '[]') AS ${tableName} FROM ( SELECT ${(0, db_1.getColumns)(tableName).filter(column => base_1.dataBase[tableName].columns[column].create !== "")} FROM "${tableName}" ) AS t`)
        .then((res) => res)
        .catch((error) => {
        console.error(error);
    });
}
function download(res) {
    var to_zip = fs.readdirSync(path.resolve(__dirname, "../import"));
    // creating archives
    const zp = new AdmZip();
    for (let k = 0; k < to_zip.length; k++) {
        zp.addLocalFile(path.resolve(__dirname, "../import") + "/" + to_zip[k]);
    }
    // toBuffer() is used to read the data and save it
    // for downloading process!
    return zp.toBuffer();
}
;
