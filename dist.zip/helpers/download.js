"use strict";
/**
 * Download file tool
 *
 * @copyright 2026-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.download = download;
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
// no type declarations available for adm-zip
const AdmZip = require("adm-zip");
function download() {
    const importDir = path_1.default.resolve(__dirname, "../import");
    const files = fs_1.default.readdirSync(importDir);
    const zip = new AdmZip();
    for (const file of files) {
        zip.addLocalFile(path_1.default.join(importDir, file));
    }
    return zip.toBuffer();
}
