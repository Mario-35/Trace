"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.update = update;
const util_1 = __importDefault(require("util"));
const exec = util_1.default.promisify(require('child_process').exec);
async function update() {
    await exec('./trace.sh');
}
