"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.toTitleCase = toTitleCase;
function toTitleCase(str) {
    try {
        return str
            .toLowerCase()
            .split(" ")
            .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
            .join(" ");
    }
    catch (error) {
        return str;
    }
}
