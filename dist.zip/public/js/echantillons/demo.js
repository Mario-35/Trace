const _DEMOS ={
    "Rien": {},
    "Basic": {
        "type": "Boues",
        "prelevement": "2026-10-09",
        "programme": "RMQS.Biodiv",
        "site": "PLEYBEN",
        "libre": "",
        "responsable": "G.Perès",
        "nombre": 9,
        "numero": 100,
        "pays": "France",
        "region": "Bretagne",
        "latitude": "48.2521082",
        "longitude": "-3.9305030",
        "dossier": "416",
        "stockage": {},
        "cultures": {}
    },
    "Gueno": {
        "type": "Sol Cultivé",
        "prelevement": "2026-06-19",
        "programme": "RMQS.Biodiv",
        "site": "Chateau-garnier",
        "libre": "",
        "responsable": "G.Perès",
        "nombre": 9,
        "dossier": "416",
        "stockage": {},
        "cultures": {}
    },
    "Risque": {
        "type": "Sol Cultivé",
        "prelevement": "2026-05-15",
        "programme": "informatique",
        "site": "Site a prevoire",
        "libre": "de toute choses",
        "responsable": "Personne",
        "nombre": 9,
        "pays": "France",
        "region": "Normandie",
        "latitude": "49.9967718",
        "longitude": "1.4312657",
        "stockage": {"Piece":"Sous sol","Batiment":"13"},
        "cultures": {}
    },
  "PasInfos": {
    "type": "Sol Cultivé",
    "prelevement": "2026-09-27",
    "programme": "Egestas Ligula Nullam Corporation",
    "site": "Site 1185",
    "libre": "Phasellus ornare. Fusce mollis. Duis",
    "responsable": "Wayne Curry",
    "nombre": 9,
    "pays": "France",
    "region": "Nord",
    "latitude": "50,7160535",
    "longitude": "1,6442706",
    "stockage": {
      "Piece": "Sous sol",
      "Batiment": "13"
    },
    "cultures": {}
  },
  "Possible": {
    "type": "Sol Cultivé",
    "prelevement": "2026-08-12",
    "programme": "Curabitur Sed Tortor Ltd",
    "site": "Site a prevoire",
    "libre": "elementum, dui quis accumsan convallis,",
    "responsable": "Geoffrey Sherman",
    "nombre": 9,
    "pays": "France",
    "region": "Grand Est",
    "latitude": "48,9702311",
    "longitude": "4,7256391",
    "stockage": {
      "Piece": "Sous sol",
      "Batiment": "13"
    },
    "cultures": {}
  },
  "Risque2": {
    "type": "Sol Cultivé",
    "prelevement": "2026-06-17",
    "programme": "Massa Integer Incorporated",
    "site": "Site a prevoire",
    "libre": "nunc. In at pede. Cras",
    "responsable": "Armando French",
    "nombre": 9,
    "pays": "France",
    "region": "Centre-Val de Loire",
    "latitude": "48,4138067",
    "longitude": "1,2425996",
    "stockage": {
      "Piece": "Sous sol",
      "Batiment": "13"
    },
    "cultures": {}
  },
  "Possible2": {
    "type": "Sol Cultivé",
    "prelevement": "2026-06-21",
    "programme": "Dapibus Id LLP",
    "site": "Site a prevoire",
    "libre": "aliquam adipiscing lacus. Ut nec",
    "responsable": "Demetria Harrison",
    "nombre": 9,
    "pays": "France",
    "region": "Pays de la Loire",
    "latitude": "47,5272638",
    "longitude": "-0,2269438",
    "stockage": {
      "Piece": "Sous sol",
      "Batiment": "13"
    },
    "cultures": {}
  },
};
