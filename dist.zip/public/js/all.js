// global form datas
let _COLUMNS = [];
const _debug = true;

function testWhere(test) {
  console.log(window.location.origin);
  
    return window.location.href.includes(test);
}

// get element by id or name with test

function getElement(name) {
  if (typeof name === "string") {
    element = document.getElementById(name);
    if (element) return element;
    if (_debug === true) console.log("element not found 🡺 " + name);
  } else return name;
};

// change element text
function setElementText(name, value) {
  const test = getElement(name);
  if (test) 
    test.innerText = value;
};

function getElementText(name) {
  const test = getElement(name);
  if (test) 
    return test.innerText;
};

// change element value
function setElementValue(name, value) {
  const test = getElement(name);
  if (test && value) 
    test.value = value;
};

// =======================> Visible
function setInvisible(element) {
  element = getElement(element);
  if(element) {
    element.classList.remove("visible");
    element.classList.add("invisible");
  }
};

function removeInvisible(element) {
  element = getElement(element);
  if (element) {
    element.classList.remove("invisible");
    element.classList.add("visible");
  }
};

function visible(element, test) {
  if (test) removeInvisible(element);
  else setInvisible(element);
};

function multiplesetInvisible(names) {
    if(typeof names === "string") names = [names];
    names.forEach(name => {
        const elem = document.getElementById(name);
        if(elem)
          setInvisible(elem.parentNode.closest('.form-group'));
      });
};

function multipleremoveInvisible(names) {
    if (typeof names === "string") names = [names];
    names.forEach(name => {
      const elem = document.getElementById(name);
        removeInvisible(elem);
        if(elem) 
          removeInvisible(elem.parentNode.closest('.form-group'));
      });
};

function setVisible(list, visible) {
    list.forEach(name => {
      const elem = document.getElementById(name);
      if (name == visible ) removeInvisible(elem);
      else  setInvisible(elem)
    });
};

// =======================> Parent Class


function showParentClass(elementName, className) {
  const elem = document.getElementById(elementName);
  if(elem)
    removeInvisible(elem.parentNode.closest('.' + className));
};

function hideParentClass(elementName, className) {
    const elem = document.getElementById(elementName);
      if(elem)
        setInvisible(elem.parentNode.closest('.' + className));
};

function parentClass(elementName, className, test) {
  if (test) showParentClass(elementName, className);
  else hideParentClass(elementName, className);
};

// =======================> Readonly

function setReadOnly(names) {
    if (typeof names === "string") names = [names];
    names.forEach(name => {
        const elem = getElement(name);
        if (elem) {
            elem.setAttribute("readonly", "");
            elem.setAttribute("disabled", "");
        }
      });
};

function removeReadOnly(names) {
    if (typeof names === "string") names = [names];
    names.forEach(name => {
        const elem = getElement(name);
        if (elem) {
            elem.removeAttribute("readonly");
            elem.removeAttribute("disabled");
        }
      });
};

function readOnly(test, element) {
    if (test) removeReadOnly(element);
        else setReadOnly(element);
};

// =======================> Disable

function setDisabled(element) {
    elem = getElement(element);
    if(elem) 
        elem.setAttribute("disabled", "");
};

function removeDisabled(element) {
    elem = getElement(element);
    if(elem) 
       elem.removeAttribute("disabled");
};

function disabled(element, test) {
  if (test) setDisabled(element);
  else removeDisabled(element);
};

function multiSetDisabled(names) {
    if(typeof names === "string") names = [names];
    names.forEach(name => setDisabled(name));
};

function multiRemoveDisabled(names) {
    if(typeof names === "string") names = [names];
    names.forEach(name => removeDisabled(name));
};
// detect is chrome
var isChrome = /Chrome/.test(navigator.userAgent) && /Google Inc/.test(navigator.vendor);

function canPrint(name) {
  disabled(name, !isChrome);
  if (isChrome === false) 
    getElement(name).title = "Uniquement avec chrome";
}

function setIfNull(element, value) {
  element = getElement(element);  
  if(element) {
    if (element.value.trim() === "" || element.value.trim() === _AUCUN)
      element.value = typeof value === "object" ? JSON.stringify(value) : value;
  }
};

// version date
setElementText("version", "version : 25/06/2026");









