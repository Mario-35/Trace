"use strict";
/**
 * Evenements routes
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.evenementsRoutes = void 0;
const express_1 = require("express");
const controller_1 = require("../../controller");
const controller_2 = require("./controller");
const db_1 = require("../../db");
const base_1 = require("../../db/base");
exports.evenementsRoutes = (0, express_1.Router)();
exports.evenementsRoutes.get("/list/" + base_1.dataBase.evenements.name, async (req, res) => {
    await (0, db_1.executeSql)(`SELECT id, ${(0, db_1.createListColumns)(base_1.dataBase.evenements.name)} FROM ${base_1.dataBase.evenements.name} ORDER BY date`)
        .then((site) => {
        return res.status(200).json(site);
    }).catch(error => {
        return res.status(404).json({ "error": error.detail });
    });
});
// Get all evenements
exports.evenementsRoutes.get("/" + base_1.dataBase.evenements.name, async (req, res) => {
    if (req.query.search)
        return await (0, controller_1.readAlSearch)(base_1.dataBase.evenements.name, String(req.query.search))
            .then((site) => {
            return res.status(200).json(site);
        }).catch(error => {
            console.error(error);
            return res.status(404).json({ "error": error.detail });
        });
    else
        return await (0, controller_1.readAll)(base_1.dataBase.evenements.name)
            .then((site) => {
            return res.status(200).json(site);
        }).catch(error => {
            console.error(error);
            return res.status(404).json({ "error": error.detail });
        });
});
// Get one evenement
exports.evenementsRoutes.get("/" + base_1.dataBase.evenements.singular + "/:id", async (req, res) => {
    return await (0, controller_1.readId)(base_1.dataBase.evenements.name, +req.params.id)
        .then((site) => {
        return site.length > 0
            ? res.status(200).json(site[0])
            : res.status(404).json({ "code": 404, "error": "Not Found" });
    }).catch(error => {
        console.error(error);
        return res.status(404).json({ "error": error.detail });
    });
});
// Create one evenement
exports.evenementsRoutes.post("/" + base_1.dataBase.evenements.singular + "", async (req, res) => {
    console.log("############# POST ############################");
    console.log(req.body);
    const values = (0, controller_1.verifyBody)(req.body);
    if (values) {
        return await (0, controller_2.addEvenement)(values)
            .then((site) => {
            return res.status(201).json(site);
        }).catch(error => {
            console.error(error);
            return res.status(error.code === 23505 ? 409 : 404).json({ "error": error.detail });
        });
    }
    else
        res.status(400).json({ "code": 400, "error": "Bad Request" });
});
// Update one evenement
exports.evenementsRoutes.patch("/" + base_1.dataBase.evenements.singular + "/:id", async (req, res) => {
    return await (0, controller_2.updateEvenement)(req.body, +req.params.id)
        .then((site) => {
        return res.status(201).json(site);
    }).catch(error => {
        console.error(error);
        return res.status(404).json({ "error": error.detail });
    });
});
// delete one evenement
exports.evenementsRoutes.delete("/" + base_1.dataBase.evenements.singular + "/:id", async (req, res) => {
    return await (0, controller_1.deleteId)(base_1.dataBase.evenements.name, +req.params.id)
        .then(() => {
        return res.status(203).json();
    }).catch(error => {
        console.error(error);
        return res.status(404).json({ "error": error.detail });
    });
});
