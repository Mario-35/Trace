"use strict";
/**
 * Evenements routes
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.evenementsRoutes = void 0;
const express_1 = require("express");
const controller_1 = require("../../controller");
const controller_2 = require("./controller");
const db_1 = require("../../db");
exports.evenementsRoutes = (0, express_1.Router)();
exports.evenementsRoutes.get("/list/evenements", async (req, res) => {
    await (0, db_1.executeSql)(`SELECT id, ${(0, db_1.createListColumns)("evenements")} FROM evenements ORDER BY date`)
        .then((site) => {
        return res.status(200).json(site);
    }).catch(error => {
        return res.status(404).json({ "error": error.detail });
    });
});
// Get all evenements
exports.evenementsRoutes.get("/evenements", async (req, res) => {
    if (req.query.search)
        return await (0, controller_1.readAlSearch)("evenements", String(req.query.search))
            .then((site) => {
            return res.status(200).json(site);
        }).catch(error => {
            console.error(error);
            return res.status(404).json({ "error": error.detail });
        });
    else
        return await (0, controller_1.readAll)("evenements")
            .then((site) => {
            return res.status(200).json(site);
        }).catch(error => {
            console.error(error);
            return res.status(404).json({ "error": error.detail });
        });
});
// Get one evenement
exports.evenementsRoutes.get("/evenement/:id", async (req, res) => {
    return await (0, controller_1.readId)("evenements", +req.params.id)
        .then((site) => {
        return site.length > 0
            ? res.status(200).json(site[0])
            : res.status(404).json({ "code": 404, "error": "Not Found" });
    }).catch(error => {
        console.error(error);
        return res.status(404).json({ "error": error.detail });
    });
});
// Create one evenement
exports.evenementsRoutes.post("/evenement", async (req, res) => {
    const values = (0, controller_1.verifyBody)(req.body);
    if (values) {
        return await (0, controller_2.addEvenement)(values)
            .then((site) => {
            return res.status(201).json(site);
        }).catch(error => {
            console.error(error);
            return res.status(error.code === 23505 ? 409 : 404).json({ "error": error.detail });
        });
    }
    else
        res.status(400).json({ "code": 400, "error": "Bad Request" });
});
// Update one evenement
exports.evenementsRoutes.patch("/evenement/:id", async (req, res) => {
    return await (0, controller_2.updateEvenement)(req.body, +req.params.id)
        .then((site) => {
        return res.status(201).json(site);
    }).catch(error => {
        console.error(error);
        return res.status(404).json({ "error": error.detail });
    });
});
// delete one evenement
exports.evenementsRoutes.delete("/evenement/:id", async (req, res) => {
    return await (0, controller_1.deleteId)("evenement", +req.params.id)
        .then(() => {
        return res.status(203).json();
    }).catch(error => {
        console.error(error);
        return res.status(404).json({ "error": error.detail });
    });
});
