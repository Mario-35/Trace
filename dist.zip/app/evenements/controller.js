"use strict";
/**
 * Events controller
 *
 * @copyright 2026-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.addEvenement = addEvenement;
exports.updateEvenement = updateEvenement;
const db_1 = require("../../db");
const base_1 = require("../../db/base");
// Create events
async function addEvenement(values) {
    const valuesCopy = { ...values };
    valuesCopy["date"] = `${valuesCopy["date"]} ${valuesCopy["time"]}`;
    return new Promise(async function (resolve, reject) {
        if (values["serie"]) {
            return await (0, db_1.executeSql)(`SELECT identification, etat AS saveetat FROM ${base_1.dataBase.echantillons.name} WHERE identification LIKE CONCAT((SELECT SUBSTRING ( identification FROM 1 FOR 12 ) FROM ${base_1.dataBase.echantillons.name} WHERE id =${values["serie"]}), '%') GROUP BY identification, etat`)
                .then(async (echantillons) => {
                const queries = [];
                Object(echantillons).forEach((echantillon) => {
                    if (values["etat"] !== "---- Laisser ----")
                        queries.push(`UPDATE ${base_1.dataBase.echantillons.name} SET etat = '${values["etat"]}' WHERE identification = '${echantillon["identification"]}'`);
                    queries.push(`${(0, db_1.createPgInsert)(base_1.dataBase.evenements.name, { ...valuesCopy, ...echantillon })}`);
                });
                return await (0, db_1.executeSql)(queries)
                    .then(async () => {
                    resolve(true);
                })
                    .catch((error) => {
                    reject(error);
                });
            })
                .catch((error) => {
                reject(error.detail);
            });
        }
        else
            return await (0, db_1.executeSql)(`${(0, db_1.createPgInsert)(base_1.dataBase.evenements.name, values)} RETURNING id`)
                .then(async (res) => {
                resolve(res[0].id);
            })
                .catch((error) => {
                console.error(error);
                reject(error);
            });
    });
}
// Update event
async function updateEvenement(values, id) {
    return new Promise(async function (resolve, reject) {
        return await (0, db_1.executeSql)(`${(0, db_1.createPgUpdate)(base_1.dataBase.evenements.name, values)} WHERE id = ${id}`)
            .then(async () => {
            const ret = await (0, db_1.sql) `SELECT * FROM ${base_1.dataBase.evenements.name} WHERE id = ${id}`;
            resolve(ret[0].id);
        })
            .catch((error) => {
            console.error(error);
            reject(error);
        });
    });
}
// no delete event allowed
