"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.addEvenement = addEvenement;
exports.updateEvenement = updateEvenement;
const db_1 = require("../../db");
const base_1 = require("../../db/base");
async function addEvenement(values) {
    return new Promise(async function (resolve, reject) {
        return await (0, db_1.executeSql)(`${(0, db_1.createPgInsert)(base_1.dataBase.evenements.name, values)} RETURNING id`)
            .then(async (res) => {
            resolve(res[0].id);
        }).catch(error => {
            console.error(error);
            reject(error);
        });
    });
}
;
async function updateEvenement(values, id) {
    return new Promise(async function (resolve, reject) {
        return await (0, db_1.executeSql)(`${(0, db_1.createPgUpdate)(base_1.dataBase.evenements.name, values)} WHERE id = ${id}`)
            .then(async () => {
            const ret = await (0, db_1.sql) `SELECT * FROM ${base_1.dataBase.evenements.name} WHERE id = ${id}`;
            resolve(ret[0].id);
        }).catch(error => {
            console.error(error);
            reject(error);
        });
    });
}
;
