"use strict";
/**
 * Pages routes
 *
 * @copyright 2026-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.pagesRoutes = void 0;
const express_1 = require("express");
const main_1 = require("../../html/class/main");
const print_1 = require("../../html/class/print");
const controller_1 = require("../../controller");
const list_1 = require("../../html/class/list");
const configuration_1 = require("../../html/class/configuration");
const db_1 = require("../../db");
const add_1 = require("../../html/class/add");
const constant_1 = require("../../constant");
const base_1 = require("../../db/base");
const update_1 = require("../../helpers/update");
const export_1 = require("../../html/class/export.js");
const documentation_1 = require("../../html/class/documentation");
const download_1 = require("../../helpers/download");
const clean_1 = require("../../helpers/clean");
const console_1 = require("console");
exports.pagesRoutes = (0, express_1.Router)();
// default index
exports.pagesRoutes.get("/index", async (req, res) => {
    const html = new main_1.Index();
    res.send(html.toString());
});
// get documentation page
exports.pagesRoutes.get("/documentation/:page", async (req, res) => {
    const html = new documentation_1.Documentation(req.params.page + ".html");
    res.send(html.toString());
});
// add sample
exports.pagesRoutes.get("/" + base_1.dataBase.echantillons.singular + "-add.html", async (req, res) => {
    const html = new add_1.Add(base_1.dataBase.echantillons.singular, constant_1._CONFIG);
    res.send(html.toString());
});
// add event
exports.pagesRoutes.get("/" + base_1.dataBase.evenements.singular + "-add.html", async (req, res) => {
    const html = new add_1.Add(base_1.dataBase.evenements.singular, constant_1._CONFIG);
    res.send(html.toString());
});
// add site
exports.pagesRoutes.get("/" + base_1.dataBase.sites.singular + "-add.html", async (req, res) => {
    const html = new add_1.Add(base_1.dataBase.sites.singular, constant_1._CONFIG);
    res.send(html.toString());
});
// add passeport
exports.pagesRoutes.get("/" + base_1.dataBase.passeports.singular + "-add.html", async (req, res) => {
    const html = new add_1.Add(base_1.dataBase.passeports.singular, constant_1._CONFIG);
    res.send(html.toString());
});
// sites page
exports.pagesRoutes.get("/" + base_1.dataBase.sites.name + ".html", async (req, res) => {
    const html = new list_1.List(base_1.dataBase.sites.name);
    res.send(html.toString());
});
// evenements page
exports.pagesRoutes.get("/" + base_1.dataBase.evenements.name + ".html", async (req, res) => {
    const html = new list_1.List(base_1.dataBase.evenements.name);
    res.send(html.toString());
});
// passeports page
exports.pagesRoutes.get("/" + base_1.dataBase.passeports.name + ".html", async (req, res) => {
    const html = new list_1.List(base_1.dataBase.passeports.name);
    res.send(html.toString());
});
// campagnes page
exports.pagesRoutes.get("/" + base_1.dataBase.campagnes.name + ".html", async (req, res) => {
    const html = new list_1.List(base_1.dataBase.campagnes.name);
    res.send(html.toString());
});
// echantillons page
exports.pagesRoutes.get("/" + base_1.dataBase.echantillons.name + ".html", async (req, res) => {
    const html = new list_1.List(base_1.dataBase.echantillons.name, true);
    res.send(html.toString());
});
// export datas
exports.pagesRoutes.get("/" + base_1.dataBase.echantillons.name + "/export/:id", async (req, res) => {
    await (0, db_1.executeSql)(`SELECT ids FROM selections WHERE id=${+req.params.id}`).then(async (ids) => {
        await (0, db_1.executeSql)(`SELECT 
            ${Object.keys(base_1.dataBase.echantillons.columns).filter((e) => base_1.dataBase.echantillons.columns[e].type !== "json" && !base_1.dataBase.echantillons.columns[e].calculate)}, 
            unnest(analyses) AS analyses 
            FROM ${base_1.dataBase.echantillons.name} WHERE id IN (${ids[0].ids})`).then((datas) => {
            const html = new export_1.Export(datas);
            res.send(html.toString());
        });
    });
});
// Update application
exports.pagesRoutes.get("/update", async (req, res) => {
    try {
        await (0, update_1.update)();
        res.send({ update: "Ok" });
        // pm2 reload app
        process.exit(0);
    }
    catch (error) {
        res.send({ error: error });
    }
});
// Clean datas
exports.pagesRoutes.get("/clean", async (req, res) => {
    await (0, clean_1.clean)();
    res.status(201).send();
});
// get programme infos
exports.pagesRoutes.get("/programme", async (req, res) => {
    let sql = undefined;
    const list = "programme, caracterisation, responsable, dossier, type, etiquette";
    if (req.url.includes("?nom="))
        sql = `SELECT ${list}, COALESCE( MAX( SUBSTRING ( identification FROM 13 FOR 4 ):: int ), 0) as numero FROM "echantillons" WHERE UPPER(programme) = ${decodeURI(req.url.split("?nom=")[1])} GROUP BY ${list} LIMIT 1`;
    else if (req.url.includes("?dossier="))
        sql = `SELECT ${list}, COALESCE( MAX( SUBSTRING ( identification FROM 13 FOR 4 ):: int ), 0) as numero FROM "echantillons" WHERE UPPER(dossier) = ${decodeURI(req.url.split("?dossier=")[1])} GROUP BY ${list} LIMIT 1`;
    if (sql)
        return (0, db_1.executeSql)(sql)
            .then((programme) => {
            res.send(programme[0] ? programme[0] : {});
        })
            .catch((error) => {
            (0, console_1.log)(error);
        });
});
// prints
exports.pagesRoutes.get("/print/:type/:id", async (req, res) => {
    switch (req.params.type) {
        case "config":
            if (constant_1._CONFIG) {
                const html = new print_1.Print("echantillon", constant_1._CONFIG);
                return res.set("Content-Type", "text/html").send(html.toString());
            }
            else
                return res.status(404).json({ error: "no config" });
        case base_1.dataBase.echantillons.singular:
            return await (0, controller_1.readId)(base_1.dataBase.echantillons.name, +req.params.id)
                .then((echantillon) => {
                const html = new print_1.Print("echantillon", echantillon);
                res.set("Content-Type", "text/html").send(html.toString());
            })
                .catch((error) => {
                console.error(error);
                return res.status(404).json({ error: error.detail });
            });
        case base_1.dataBase.selections.singular:
            return await (0, controller_1.readId)(base_1.dataBase.selections.name, +req.params.id)
                .then(async (selection) => {
                return await (0, controller_1.readIds)(base_1.dataBase.echantillons.name, selection[0].ids)
                    .then(async (all) => {
                    const html = new print_1.Print("echantillon", all);
                    res.set("Content-Type", "text/html").send(html.toString());
                })
                    .catch((error) => {
                    console.error(error);
                    return res.status(404).json({ error: error.detail });
                });
            })
                .catch((error) => {
                console.error(error);
                return res.status(404).json({ error: error.detail });
            });
        case base_1.dataBase.passeports.singular:
            return await (0, controller_1.readId)(base_1.dataBase.passeports.name, +req.params.id)
                .then((passeport) => {
                const html = new print_1.Print("passeport", passeport);
                res.set("Content-Type", "text/html").send(html.toString());
            })
                .catch((error) => {
                console.error(error);
                return res.status(404).json({ error: error.detail });
            });
        case "identification":
            return await (0, db_1.executeSql)(`SELECT * FROM ${base_1.dataBase.echantillons.name} WHERE identification LIKE '${req.params.id.slice(0, 12)}%'`)
                .then(async (all) => {
                const html = new print_1.Print("echantillon", all);
                res.set("Content-Type", "text/html").send(html.toString());
            })
                .catch((error) => {
                console.error(error);
                return res.status(404).json({ error: error.detail });
            });
        case "echantillonPasseport":
            console.log("ici todo");
        default:
            break;
    }
});
// save configuration
exports.pagesRoutes.post("/SaveConfig", async (req, res) => {
    (0, constant_1.setConfig)(req.body);
    res.status(201).send();
});
// configuration page
exports.pagesRoutes.get("/configuration.html", async (req, res) => {
    await (0, controller_1.readId)(base_1.dataBase.configuration.name, 1)
        .then((configuration) => {
        res.send(new configuration_1.Configuration(configuration[0]).toString());
    })
        .catch((error) => {
        console.error(error);
    });
});
// download export datas
exports.pagesRoutes.get("/download", async (req, res) => {
    (0, db_1.writeDB)().then(() => {
        const data = (0, download_1.download)();
        res.set("Content-Type", "application/octet-stream");
        res.set("Content-Disposition", `attachment; filename=download_${new Date().toJSON().slice(0, 16).replaceAll("-", "").replace(":", "")}.zip`);
        res.set("Content-Length", data.length);
        res.send(data);
    });
});
