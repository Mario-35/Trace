"use strict";
/**
 * Pages routes
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.pagesRoutes = void 0;
const express_1 = require("express");
const main_1 = require("../../html/class/main");
const print_1 = require("../../html/class/print");
const controller_1 = require("../../controller");
const list_1 = require("../../html/class/list");
const configuration_1 = require("../../html/class/configuration");
const db_1 = require("../../db");
const add_1 = require("../../html/class/add");
const constant_1 = require("../../constant");
exports.pagesRoutes = (0, express_1.Router)();
// Get all echantillons
exports.pagesRoutes.get("/index", async (req, res) => {
    const html = new main_1.Index();
    res.send(html.toString());
});
// add sample
exports.pagesRoutes.get("/echantillon-add.html", async (req, res) => {
    const html = new add_1.Add("echantillon", constant_1._CONFIG);
    res.send(html.toString());
});
// add event
exports.pagesRoutes.get("/evenement-add.html", async (req, res) => {
    const html = new add_1.Add("evenement", constant_1._CONFIG);
    res.send(html.toString());
});
// add site
exports.pagesRoutes.get("/site-add.html", async (req, res) => {
    const html = new add_1.Add("site", constant_1._CONFIG);
    res.send(html.toString());
});
// selection page
exports.pagesRoutes.get("/selections.html", async (req, res) => {
    const html = new list_1.List("Selection");
    res.send(html.toString());
});
// sites page
exports.pagesRoutes.get("/sites.html", async (req, res) => {
    const html = new list_1.List("Site");
    res.send(html.toString());
});
// evenements page
exports.pagesRoutes.get("/evenements.html", async (req, res) => {
    const html = new list_1.List("Evenement");
    res.send(html.toString());
});
// passeports page
exports.pagesRoutes.get("/passeports.html", async (req, res) => {
    const html = new list_1.List("Passeport");
    res.send(html.toString());
});
// campagnes page
exports.pagesRoutes.get("/campagnes.html", async (req, res) => {
    const html = new list_1.List("Campagne");
    res.send(html.toString());
});
// echantillons page
exports.pagesRoutes.get("/echantillons.html", async (req, res) => {
    const html = new list_1.List("Echantillon", true);
    res.send(html.toString());
});
// print sample sticker
exports.pagesRoutes.get("/print/:type", async (req, res) => {
    switch (req.params.type) {
        case 'echantillon':
            const html = new print_1.Print("echantillon", [constant_1._CONFIG]);
            return res.set('Content-Type', 'text/html').send(html.toString());
    }
});
// prints
exports.pagesRoutes.get("/print/:type/:id", async (req, res) => {
    switch (req.params.type) {
        case 'config':
            if (constant_1._CONFIG) {
                const html = new print_1.Print("echantillon", constant_1._CONFIG);
                return res.set('Content-Type', 'text/html').send(html.toString());
            }
            else
                return res.status(404).json({ "error": "no config" });
        case 'echantillon':
            return await (0, controller_1.readId)("echantillons", +req.params.id).then((echantillon) => {
                const html = new print_1.Print("echantillon", echantillon);
                res.set('Content-Type', 'text/html').send(html.toString());
            }).catch(error => {
                console.error(error);
                return res.status(404).json({ "error": error.detail });
            });
        case 'selection':
            return await (0, controller_1.readId)("selections", +req.params.id).then(async (selection) => {
                return await (0, controller_1.readIds)("echantillons", selection[0].ids).then(async (all) => {
                    const html = new print_1.Print("echantillon", all);
                    res.set('Content-Type', 'text/html').send(html.toString());
                }).catch(error => {
                    console.error(error);
                    return res.status(404).json({ "error": error.detail });
                });
            }).catch(error => {
                console.error(error);
                return res.status(404).json({ "error": error.detail });
            });
        case 'passeport':
            return await (0, controller_1.readId)("passeports", +req.params.id).then((passeport) => {
                const html = new print_1.Print("passeport", passeport);
                res.set('Content-Type', 'text/html').send(html.toString());
            }).catch(error => {
                console.error(error);
                return res.status(404).json({ "error": error.detail });
            });
        case 'identification':
            return await (0, db_1.executeSql)(`SELECT * FROM echantillons WHERE identification LIKE '${req.params.id.slice(0, 12)}%'`).then(async (all) => {
                const html = new print_1.Print("echantillon", all);
                res.set('Content-Type', 'text/html').send(html.toString());
            }).catch(error => {
                console.error(error);
                return res.status(404).json({ "error": error.detail });
            });
        case 'echantillonPasseport':
            console.log("ici todo");
        default:
            break;
    }
    ;
});
exports.pagesRoutes.post("/SaveConfig", async (req, res) => {
    (0, constant_1.setConfig)(req.body);
    res.status(201).send();
});
// configuration page
exports.pagesRoutes.get("/configuration.html", async (req, res) => {
    const html = new configuration_1.Configuration();
    res.send(html.toString());
});
