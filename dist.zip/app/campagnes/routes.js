"use strict";
/**
 * Campagnes routes
 *
 * @copyright 2026-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.campagnesRoutes = void 0;
const express_1 = require("express");
const db_1 = require("../../db");
const removeReturns_1 = require("../../helpers/removeReturns");
const base_1 = require("../../db/base");
exports.campagnesRoutes = (0, express_1.Router)();
// Get all campagnes note that there is no table for that it's "calculate"
exports.campagnesRoutes.get("/list/" + base_1.dataBase.campagnes.name, async (req, res) => {
    return await (0, db_1.executeSql)((0, removeReturns_1.removeReturns)(`WITH 
        src AS (
            SELECT 
            DISTINCT ON(
                SUBSTRING (
                COALESCE(parent, identification) FROM 1 FOR 12 )
            ) SUBSTRING (
                COALESCE(parent, identification) FROM 1 FOR 12
            ) as id, 
            type, 
            dossier, 
            creation, 
            prelevement, 
            programme, 
            site, 
            responsable 
            FROM 
            ${base_1.dataBase.echantillons.name}
        ) 
        SELECT 
            src.id AS id, 
            ${(0, db_1.getListColumns)(base_1.dataBase.campagnes.name)} 
        FROM 
            src 
        ORDER BY 
            creation`))
        .then((site) => {
        return res.status(200).json(site);
    })
        .catch((error) => {
        return res.status(404).json({ error: error.detail });
    });
});
