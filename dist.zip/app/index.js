"use strict";
/**
 * App index
 *
 * @copyright 2026-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.campagnesRoutes = exports.rpgsRoutes = exports.selectionsRoutes = exports.excelsRoutes = exports.configRoutes = exports.pagesRoutes = exports.evenementsRoutes = exports.sitesRoutes = exports.passeportsRoutes = exports.echantillonsRoutes = void 0;
var routes_1 = require("./echantillons/routes");
Object.defineProperty(exports, "echantillonsRoutes", { enumerable: true, get: function () { return routes_1.echantillonsRoutes; } });
var routes_2 = require("./passeports/routes");
Object.defineProperty(exports, "passeportsRoutes", { enumerable: true, get: function () { return routes_2.passeportsRoutes; } });
var routes_3 = require("./sites/routes");
Object.defineProperty(exports, "sitesRoutes", { enumerable: true, get: function () { return routes_3.sitesRoutes; } });
var routes_4 = require("./evenements/routes");
Object.defineProperty(exports, "evenementsRoutes", { enumerable: true, get: function () { return routes_4.evenementsRoutes; } });
var routes_5 = require("./pages/routes");
Object.defineProperty(exports, "pagesRoutes", { enumerable: true, get: function () { return routes_5.pagesRoutes; } });
var routes_6 = require("./configuration/routes");
Object.defineProperty(exports, "configRoutes", { enumerable: true, get: function () { return routes_6.configRoutes; } });
var routes_7 = require("./excels/routes");
Object.defineProperty(exports, "excelsRoutes", { enumerable: true, get: function () { return routes_7.excelsRoutes; } });
var routes_8 = require("./selections/routes");
Object.defineProperty(exports, "selectionsRoutes", { enumerable: true, get: function () { return routes_8.selectionsRoutes; } });
var routes_9 = require("./rpg/routes");
Object.defineProperty(exports, "rpgsRoutes", { enumerable: true, get: function () { return routes_9.rpgsRoutes; } });
var routes_10 = require("./campagnes/routes");
Object.defineProperty(exports, "campagnesRoutes", { enumerable: true, get: function () { return routes_10.campagnesRoutes; } });
