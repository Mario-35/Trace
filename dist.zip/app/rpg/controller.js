"use strict";
/**
 * Rpg controller
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.getRpg = getRpg;
const logger_1 = require("../../infra/logger");
/**
 *
 * @param x ws84 lattitude position
 * @param y ws84 longiitude position
 * @returns JSON object with years and value code
*/
async function getRpg(x, y) {
    const results = {};
    const maxYear = new Date().getFullYear();
    let departement = undefined;
    /**
     *
     * @param annee year of daerc
     * @param x ws84 lattitude position
     * @param y ws84 longiitude position
     * @returns JSON object with years and value code
     */
    async function getRpgDatas(annee, x, y) {
        let url = 'https://apicarto.ign.fr/api/rpg/v';
        url += annee < 2015 ? '1' : '2';
        url += '?annee=' + annee + '&geom={"type": "Point", "coordinates": [' + x + ', ' + y + ']}';
        return fetch(encodeURI(url), {
            method: "GET",
            headers: {
                "Content-Type": "application/json",
            },
        }).then(async (response) => {
            return await response.json().then((res) => {
                try {
                    if (res["features"][0]["properties"]["dep_rattac"])
                        departement = res["features"][0]["properties"]["dep_rattac"];
                    return res["code"] === 400 ? "NOT" : res["features"][0]["properties"]["code_cultu"];
                }
                catch (error) {
                    return "NOT";
                }
            });
        }).catch((error) => {
            logger_1.logger.error(error);
        });
    }
    for (let year = maxYear - 15; year <= maxYear; year++) {
        results[year] = await getRpgDatas(year, x, y) || "NOT";
        if (departement)
            results["departement"] = departement;
    }
    return results;
}
;
