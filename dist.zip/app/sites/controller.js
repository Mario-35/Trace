"use strict";
/**
 * Sites controller
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.addSite = addSite;
exports.updateSite = updateSite;
const db_1 = require("../../db");
async function addSite(values) {
    return new Promise(async function (resolve, reject) {
        return await (0, db_1.executeSql)(`${(0, db_1.createPgInsert)("sites", values)} RETURNING id`)
            .then(async (res) => {
            resolve(res[0].id);
        }).catch(error => {
            reject(error);
        });
    });
}
;
async function updateSite(values, id) {
    return new Promise(async function (resolve, reject) {
        return await (0, db_1.executeSql)(`${(0, db_1.createPgUpdate)("sites", values)} WHERE id = ${id}`)
            .then(async () => {
            const ret = await (0, db_1.sql) `SELECT * FROM sites WHERE id = ${id}`;
            resolve(ret[0].id);
        }).catch(error => {
            reject(error);
        });
    });
}
;
