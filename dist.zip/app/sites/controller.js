"use strict";
/**
 * Sites controller
 *
 * @copyright 2026-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.addSite = addSite;
exports.updateSite = updateSite;
const controller_1 = require("../../controller");
const db_1 = require("../../db");
const base_1 = require("../../db/base");
// add one site
async function addSite(values) {
    return new Promise(async function (resolve, reject) {
        return await (0, db_1.executeSql)(`${(0, db_1.createPgInsert)(base_1.dataBase.sites.name, values)} RETURNING id`)
            .then(async (res) => {
            resolve(res[0].id);
        }).catch(error => {
            console.error(error);
            reject(error);
        });
    });
}
;
// update one site
async function updateSite(values, id) {
    return new Promise(async function (resolve, reject) {
        return await (0, db_1.executeSql)(`${(0, db_1.createPgUpdate)(base_1.dataBase.sites.name, values)} WHERE id = ${id}`)
            .then(async () => {
            const ret = await (0, controller_1.readId)(base_1.dataBase.sites.name, id)
                .then((ret) => {
                resolve(ret[0].id);
            }).catch(error => {
                console.error(error);
                reject(error);
            });
        }).catch(error => {
            console.error(error);
            reject(error);
        });
    });
}
;
