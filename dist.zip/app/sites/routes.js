"use strict";
/**
 * Sites routes
 *
 * @copyright 2026-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.sitesRoutes = void 0;
const express_1 = require("express");
const controller_1 = require("../../controller");
const controller_2 = require("./controller");
const db_1 = require("../../db");
const asyncForEach_1 = require("../../helpers/asyncForEach");
const base_1 = require("../../db/base");
exports.sitesRoutes = (0, express_1.Router)();
// Get all sites
exports.sitesRoutes.get("/sites", async (req, res) => {
    if (req.query.search)
        return await (0, controller_1.readAlSearch)(base_1.dataBase.sites.name, String(req.query.search))
            .then((site) => {
            return res.status(200).json(site);
        })
            .catch((error) => {
            console.error(error);
            return res.status(404).json({ error: error.detail });
        });
    else
        return await (0, controller_1.readAll)(base_1.dataBase.sites.name)
            .then((site) => {
            return res.status(200).json(site);
        })
            .catch((error) => {
            console.error(error);
            return res.status(404).json({ error: error.detail });
        });
});
// Get one site
exports.sitesRoutes.get("/" + base_1.dataBase.sites.singular + "/:id", async (req, res) => {
    return await (0, controller_1.readId)(base_1.dataBase.sites.name, +req.params.id)
        .then((site) => {
        return site.length > 0
            ? res.status(200).json(site[0])
            : res.status(404).json({ code: 404, error: "Not Found" });
    })
        .catch((error) => {
        console.error(error);
        return res.status(404).json({ error: error.detail });
    });
});
// get site by is name search
exports.sitesRoutes.get("/" + base_1.dataBase.sites.name + "/search/:name", async (req, res) => {
    return await (0, db_1.executeSql)(`SELECT * FROM ${base_1.dataBase.sites.name} WHERE UPPER(nom) LIKE '%${String(req.params.name).toUpperCase()}%'`)
        .then((sites) => {
        return sites.length > 0
            ? res.status(200).json(sites)
            : res.status(404).json({ code: 404, error: "Not Found" });
    })
        .catch((error) => {
        console.error(error);
        return res.status(404).json({ error: error.detail });
    });
});
// Create one site
exports.sitesRoutes.post("/" + base_1.dataBase.sites.singular, async (req, res) => {
    const values = (0, controller_1.verifyBody)(req.body);
    if (values) {
        return await (0, controller_2.addSite)(values)
            .then((site) => {
            return res.status(201).json(site);
        })
            .catch((error) => {
            console.error(error);
            return res.status(error.code === 23505 ? 409 : 404).json({ error: error.detail });
        });
    }
    else
        res.status(400).json({ code: 400, error: "Bad Request" });
});
// Get all search site for excel import list correspondance it's à post to catch datas search posted
exports.sitesRoutes.post("/" + base_1.dataBase.sites.singular + "/rapprochement", async (req, res) => {
    const result = {};
    await (0, asyncForEach_1.asyncForEach)(req.body.unique, async (name) => {
        await (0, db_1.executeSqlValues)(`SELECT nom FROM ${base_1.dataBase.sites.name} WHERE UPPER(nom) LIKE '${name.toUpperCase()}%'`)
            .then((res) => {
            result[name] = res[0] ? String(res[0]) : "Non Trouvé";
        })
            .catch((error) => {
            console.error(error);
            return res.status(404).json({ error: error.detail });
        });
    });
    return res.status(201).json(result);
});
// Update one site
exports.sitesRoutes.patch("/" + base_1.dataBase.sites.singular + "/:id", async (req, res) => {
    return await (0, controller_2.updateSite)(req.body, +req.params.id)
        .then((site) => {
        return res.status(201).json(site);
    })
        .catch((error) => {
        console.error(error);
        return res.status(404).json({ error: error.detail });
    });
});
// delete one site
exports.sitesRoutes.delete("/" + base_1.dataBase.sites.singular + "/:id", async (req, res) => {
    return await (0, controller_1.deleteId)(base_1.dataBase.sites.name, +req.params.id)
        .then(() => {
        return res.status(203).json();
    })
        .catch((error) => {
        console.error(error);
        return res.status(404).json({ error: error.detail });
    });
});
// for datalists but not used
exports.sitesRoutes.get("/" + base_1.dataBase.sites.name + "/filter/:name", async (req, res) => {
    return await (0, db_1.executeSqlValues)(`SELECT nom FROM ${base_1.dataBase.sites.name} WHERE UPPER(nom) LIKE '${String(req.params.name).toUpperCase()}%'`).then((sites) => {
        return res.status(201).json(sites.map((e) => e[0]));
    });
});
