"use strict";
/**
 * Sites routes
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.sitesRoutes = void 0;
const express_1 = require("express");
const controller_1 = require("../../controller");
const controller_2 = require("./controller");
const db_1 = require("../../db");
const asyncForEach_1 = require("../../helpers/asyncForEach");
exports.sitesRoutes = (0, express_1.Router)();
// Get all sites
exports.sitesRoutes.get("/sites", async (req, res) => {
    if (req.query.search)
        return await (0, controller_1.readAlSearch)("sites", String(req.query.search))
            .then((site) => {
            return res.status(200).json(site);
        }).catch(error => {
            console.error(error);
            return res.status(404).json({ "error": error.detail });
        });
    else
        return await (0, controller_1.readAll)("sites")
            .then((site) => {
            return res.status(200).json(site);
        }).catch(error => {
            console.error(error);
            return res.status(404).json({ "error": error.detail });
        });
});
// Get one site
exports.sitesRoutes.get("/site/:id", async (req, res) => {
    return await (0, controller_1.readId)("sites", +req.params.id)
        .then((site) => {
        return site.length > 0
            ? res.status(200).json(site[0])
            : res.status(404).json({ "code": 404, "error": "Not Found" });
    }).catch(error => {
        console.error(error);
        return res.status(404).json({ "error": error.detail });
    });
});
// get site by name
exports.sitesRoutes.get("/sites/search/:name", async (req, res) => {
    return await (0, db_1.executeSql)(`SELECT * FROM sites WHERE UPPER(nom) LIKE '%${req.params.name.toUpperCase()}%'`).then((sites) => {
        return sites.length > 0
            ? res.status(200).json(sites)
            : res.status(404).json({ "code": 404, "error": "Not Found" });
    }).catch(error => {
        console.error(error);
        return res.status(404).json({ "error": error.detail });
    });
});
// Create one site
exports.sitesRoutes.post("/site", async (req, res) => {
    const values = (0, controller_1.verifyBody)(req.body);
    if (values) {
        return await (0, controller_2.addSite)(values)
            .then((site) => {
            return res.status(201).json(site);
        }).catch(error => {
            console.error(error);
            return res.status(error.code === 23505 ? 409 : 404).json({ "error": error.detail });
        });
    }
    else
        res.status(400).json({ "code": 400, "error": "Bad Request" });
});
// Get all search site for excel import list correspondance
exports.sitesRoutes.post("/site/rapprochement", async (req, res) => {
    const result = {};
    await (0, asyncForEach_1.asyncForEach)(req.body.unique, async (name) => {
        await (0, db_1.executeSqlValues)(`SELECT nom FROM sites WHERE UPPER(nom) LIKE '${name.toUpperCase()}%'`)
            .then((res) => {
            result[name] = res[0] ? String(res[0]) : "Non Trouvé";
        }).catch(error => {
            console.error(error);
            return res.status(404).json({ "error": error.detail });
        });
    });
    return res.status(201).json(result);
});
// Update one site
exports.sitesRoutes.patch("/site/:id", async (req, res) => {
    return await (0, controller_2.updateSite)(req.body, +req.params.id)
        .then((site) => {
        return res.status(201).json(site);
    }).catch(error => {
        console.error(error);
        return res.status(404).json({ "error": error.detail });
    });
});
// delete one site
exports.sitesRoutes.delete("/site/:id", async (req, res) => {
    return await (0, controller_1.deleteId)("sites", +req.params.id)
        .then(() => {
        return res.status(203).json();
    }).catch(error => {
        console.error(error);
        return res.status(404).json({ "error": error.detail });
    });
});
// for datalists but not used
exports.sitesRoutes.get("/sites/filter/:name", async (req, res) => {
    return await (0, db_1.executeSqlValues)(`SELECT nom FROM sites WHERE UPPER(nom) LIKE '${req.params.name.toUpperCase()}%'`).then((sites) => {
        return res.status(201).json(sites.map((e) => e[0]));
    });
});
