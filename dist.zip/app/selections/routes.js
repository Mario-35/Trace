"use strict";
/**
 * Selections routes
 *
 * @copyright 2026-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.selectionsRoutes = void 0;
const express_1 = require("express");
const controller_1 = require("../../controller");
const db_1 = require("../../db");
const base_1 = require("../../db/base");
exports.selectionsRoutes = (0, express_1.Router)();
// Get selection
exports.selectionsRoutes.get("/" + base_1.dataBase.selections.singular + "/:id", async (req, res) => {
    return await (0, controller_1.readId)(base_1.dataBase.selections.name, +req.params.id)
        .then(async (selection) => {
        return await (0, controller_1.readIds)(base_1.dataBase.echantillons.name, selection[0].ids)
            .then(async (all) => {
            return res.status(200).json(all);
        })
            .catch((error) => {
            console.error(error);
            return res.status(404).json({ error: error.detail });
        });
    })
        .catch((error) => {
        console.error(error);
        return res.status(404).json({ error: error.detail });
    });
});
// Create one selection
exports.selectionsRoutes.post("/" + base_1.dataBase.selections.singular, async (req, res) => {
    return await (0, db_1.executeSql)(`INSERT INTO ${base_1.dataBase.selections.name} (ids) VALUES ('{${req.body.ids}}') RETURNING id`)
        .then((selection) => {
        return res.status(201).json(selection);
    })
        .catch((error) => {
        console.error(error);
        return res.status(error.code === 23505 ? 409 : 404).json({ error: error.detail });
    });
});
// delete one selection
exports.selectionsRoutes.delete("/" + base_1.dataBase.selections.singular + "/:id", async (req, res) => {
    return await (0, controller_1.deleteId)(base_1.dataBase.selections.name, +req.params.id)
        .then(() => {
        return res.status(203).json();
    })
        .catch((error) => {
        console.error(error);
        return res.status(404).json({ error: error.detail });
    });
});
