"use strict";
/**
 * Selection controller
 *
 * @copyright 2026-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.addSelection = addSelection;
const db_1 = require("../../db");
const base_1 = require("../../db/base");
// add a selection
async function addSelection(values) {
    return await (0, db_1.executeSql)(`INSERT INTO ${base_1.dataBase.selections.name} (ids) VALUES ('{${values}}') RETURNING id`);
}
