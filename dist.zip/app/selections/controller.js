"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.addSelection = addSelection;
const db_1 = require("../../db");
async function addSelection(values) {
    return await (0, db_1.executeSql)(`INSERT INTO selections (ids) VALUES ('{${values}}') RETURNING id`);
}
