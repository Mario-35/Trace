"use strict";
/**
 * Excels routes
 *
 * @copyright 2026-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.excelsRoutes = void 0;
const express_1 = require("express");
const controller_1 = require("../../controller");
const db_1 = require("../../db");
const escapeSimpleQuotes_1 = require("../../helpers/escapeSimpleQuotes");
const base_1 = require("../../db/base");
exports.excelsRoutes = (0, express_1.Router)();
exports.excelsRoutes.get("/" + base_1.dataBase.excels.singular + "/:id", async (req, res) => {
    return await (0, controller_1.readId)(base_1.dataBase.excels.name, +req.params.id)
        .then((excel) => {
        return excel.length > 0
            ? res.status(200).json(excel[0].datas)
            : res.status(404).json({ "code": 404, "message": "Not Found" });
    }).catch(error => {
        console.error(error);
        return res.status(404).json({ "error": error.detail });
    });
});
exports.excelsRoutes.post("/" + base_1.dataBase.excels.singular, async (req, res) => {
    return await (0, db_1.executeSql)(`INSERT INTO ${base_1.dataBase.excels.name} (datas) VALUES ('${(0, escapeSimpleQuotes_1.escapeSimpleQuotes)(JSON.stringify(req.body))}') RETURNING id`)
        .then((excel) => {
        return res.status(201).json(excel);
    }).catch(error => {
        console.error(error);
        return res.status(error.code === 23505 ? 409 : 404).json({ "error": error.detail });
    });
});
// delete one sample
exports.excelsRoutes.delete("/" + base_1.dataBase.excels.singular + "/:id", async (req, res) => {
    return await (0, controller_1.deleteId)(base_1.dataBase.excels.name, +req.params.id)
        .then(() => {
        return res.status(203).json();
    }).catch(error => {
        return res.status(404).json({ "error": error.detail });
    });
});
