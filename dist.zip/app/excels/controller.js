"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.addExcel = addExcel;
const db_1 = require("../../db");
const escapeSimpleQuotes_1 = require("../../helpers/escapeSimpleQuotes");
async function addExcel(values) {
    return await (0, db_1.executeSql)(`INSERT INTO excels (datas) VALUES ('${(0, escapeSimpleQuotes_1.escapeSimpleQuotes)(JSON.stringify(values))}') RETURNING id`);
}
