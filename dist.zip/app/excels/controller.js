"use strict";
/**
 * Excel controller
 *
 * @copyright 2026-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.addExcel = addExcel;
const db_1 = require("../../db");
const base_1 = require("../../db/base");
const escapeSimpleQuotes_1 = require("../../helpers/escapeSimpleQuotes");
// add excels import datas
async function addExcel(values) {
    return await (0, db_1.executeSql)(`INSERT INTO ${base_1.dataBase.excels.name} (datas) VALUES ('${(0, escapeSimpleQuotes_1.escapeSimpleQuotes)(JSON.stringify(values))}') RETURNING id`);
}
