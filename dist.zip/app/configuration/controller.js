"use strict";
/**
 * Configuration controller
 *
 * @copyright 2026-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.readConfig = readConfig;
exports.createConfig = createConfig;
exports.writeConfig = writeConfig;
exports.saveConfig = saveConfig;
const db_1 = require("../../db");
const path_1 = __importDefault(require("path"));
const util_1 = __importDefault(require("util"));
const fs_1 = __importDefault(require("fs"));
const base_1 = require("../../db/base");
const controller_1 = require("../../controller");
// Read configuration
async function readConfig() {
    return await (0, db_1.executeSql)(`SELECT * FROM configuration WHERE id = 1`);
}
// Create configuration
function createConfig(configuration) {
    configuration = configuration || {};
    configuration["excelColumns"] = Object.keys(base_1.dataBase.echantillons.columns).filter((e) => base_1.dataBase.echantillons.columns[e].excel);
    configuration["stickerElements"] =
        Object.keys(base_1.dataBase.echantillons.columns).filter(e => base_1.dataBase.echantillons.columns[e].etiquette).reduce((acc, item) => ({ ...acc, [item]: String(base_1.dataBase.echantillons.columns[item].etiquette) }), {});
    return configuration;
}
// Write configuration file
function writeConfigurationFile(configuration) {
    configuration["excelColumns"] = Object.keys(base_1.dataBase.echantillons.columns).filter((e) => base_1.dataBase.echantillons.columns[e].excel);
    console.log(configuration);
    ["etats", "types", "passeports", "caracterisations", "sizes"].forEach((e) => {
        configuration[e] = configuration[e].split(",");
    });
    configuration["stickerElements"] =
        Object.keys(base_1.dataBase.echantillons.columns).filter(e => base_1.dataBase.echantillons.columns[e].etiquette).reduce((acc, item) => ({ ...acc, [item]: String(base_1.dataBase.echantillons.columns[item].etiquette) }), {});
    fs_1.default.writeFile(path_1.default.resolve(__dirname, "../../public/js/", "configuration.js"), `_CONFIGURATION = ${util_1.default.inspect(configuration, { showHidden: false, depth: null, colors: false })};`, (error) => {
        console.error(`Ecriture de la configuration : ${error || "Ok"}`);
    });
}
// Save configuration
async function writeConfig() {
    (0, controller_1.readId)(base_1.dataBase.configuration.name, 1)
        .then((configuration) => {
        writeConfigurationFile(configuration[0]);
    })
        .catch((error) => {
        console.error(error);
    });
}
// Save configuration and write File
async function saveConfig(values) {
    return new Promise(async function (resolve, reject) {
        return await (0, db_1.executeSql)(`${(0, db_1.createPgUpdate)(base_1.dataBase.configuration.name, values)} WHERE id = 1`)
            .then(async (ret) => {
            await writeConfig();
            resolve(ret);
        })
            .catch((error) => {
            console.error(error);
            reject(error);
        });
    });
}
