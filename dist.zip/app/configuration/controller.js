"use strict";
/**
 * Configuration controller
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.readConfig = readConfig;
exports.createConfig = createConfig;
exports.writeConfig = writeConfig;
exports.saveConfig = saveConfig;
const db_1 = require("../../db");
const path_1 = __importDefault(require("path"));
const util_1 = __importDefault(require("util"));
const fs_1 = __importDefault(require("fs"));
const base_1 = require("../../db/base");
// Read configuration
async function readConfig() {
    // return await executeSql(`SELECT * FROM configuration WHERE id = 1`);
}
;
// Create configuration
function createConfig(configuration) {
    configuration = configuration || {};
    configuration["excelColumns"] = Object.keys(base_1.dataBase.echantillons.columns).filter(e => base_1.dataBase.echantillons.columns[e].excel);
    configuration["stickerElements"] = JSON.parse(`{"echantillon": "1902202617320002", "dossier":"0429", "numero":"0002", "prelevement":"2026-03-04", "peremption":"2031-03-04", "passeport":"2026-0003", "dossier-numero":"0429-0002", ${Object.keys(base_1.dataBase.echantillons.columns).filter(e => base_1.dataBase.echantillons.columns[e].etiquette).map(e => `"${e}" : "${base_1.dataBase.echantillons.columns[e].etiquette}"`)}}`);
    return configuration;
}
// Write configuration file
function writeConfigurationFile(configuration) {
    configuration["excelColumns"] = Object.keys(base_1.dataBase.echantillons.columns).filter(e => base_1.dataBase.echantillons.columns[e].excel);
    configuration["stickerElements"] = JSON.parse(`{"echantillon": "1902202617320002", "dossier":"0429", "numero":"0002", "prelevement":"2026-03-04", "peremption":"2031-03-04", "passeport":"2026-0003", "dossier-numero":"0429-0002",
                                                      ${Object.keys(base_1.dataBase.echantillons.columns).filter(e => base_1.dataBase.echantillons.columns[e].etiquette).map(e => `"${e}" : "${base_1.dataBase.echantillons.columns[e].etiquette}"`)}}`);
    fs_1.default.writeFile(path_1.default.resolve(__dirname, "../../public/js/", "configuration.js"), `_CONFIGURATION = ${util_1.default.inspect(configuration, { showHidden: false, depth: null, colors: false })};`, (error) => {
        console.log(`Ecriture de la configuration : ${error || "Ok"}`);
    });
}
// Write configuration file
async function writeConfig() {
    (0, db_1.executeSql)(`SELECT * FROM configuration WHERE id = 1`)
        .then((configuration) => {
        writeConfigurationFile(configuration[0]);
    }).catch(error => {
        console.error(error);
    });
}
// Save configuration
async function saveConfig(values) {
    return new Promise(async function (resolve, reject) {
        return await (0, db_1.executeSql)(`${(0, db_1.createPgUpdate)("configuration", values)} WHERE id = 1`)
            .then(async (ret) => {
            await writeConfig();
            resolve(ret);
        }).catch(error => {
            reject(error);
        });
    });
}
;
