"use strict";
/**
 * Configuration routes
 *
 * @copyright 2026-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.configRoutes = void 0;
const express_1 = require("express");
const controller_1 = require("./controller");
const base_1 = require("../../db/base");
exports.configRoutes = (0, express_1.Router)();
// Get configuration
exports.configRoutes.get("/" + base_1.dataBase.configuration.name, async (req, res) => {
    return await (0, controller_1.readConfig)()
        .then((config) => {
        return config.length > 0
            ? res.status(200).json(config[0])
            : res.status(404).json({ "code": 404, "error": "Not Found" });
    }).catch(error => {
        return res.status(404).json({ "error": error.detail });
    });
});
// Create one configuration
exports.configRoutes.post("/" + base_1.dataBase.configuration.name, async (req, res) => {
    return await (0, controller_1.saveConfig)(req.body)
        .then((config) => {
        return res.status(201).json(config);
    }).catch(error => {
        return res.status(error.code === 23505 ? 409 : 404).json({ "error": error.detail });
    });
});
// Update one configuration
exports.configRoutes.patch("/" + base_1.dataBase.configuration.name, async (req, res) => {
    return await (0, controller_1.saveConfig)(req.body)
        .then((config) => {
        return res.status(201).json(config);
    }).catch((error) => {
        return res.status(404).json({ "error": error.detail });
    });
});
