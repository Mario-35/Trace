"use strict";
/**
 * Passeports routes
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.passeportsRoutes = void 0;
const express_1 = require("express");
const controller_1 = require("../../controller");
const controller_2 = require("./controller");
const db_1 = require("../../db");
exports.passeportsRoutes = (0, express_1.Router)();
// Get all passeports
exports.passeportsRoutes.get("/passeports", async (req, res) => {
    if (req.query.search)
        return await (0, controller_1.readAlSearch)("passeports", String(req.query.search))
            .then((passeport) => {
            return res.status(200).json(passeport);
        }).catch(error => {
            console.error(error);
            return res.status(404).json({ "error": error.detail });
        });
    else
        return await (0, controller_1.readAll)("passeports")
            .then((passeport) => {
            return res.status(200).json(passeport);
        }).catch(error => {
            console.error(error);
            return res.status(404).json({ "error": error.detail });
        });
});
// Get one passeport
exports.passeportsRoutes.get("/passeport/:id", async (req, res) => {
    return await (0, controller_1.readId)("passeports", +req.params.id)
        .then((passeport) => {
        return passeport.length > 0
            ? res.status(200).json(passeport[0])
            : res.status(404).json({ "code": 404, "error": "Not Found" });
    }).catch(error => {
        console.error(error);
        return res.status(404).json({ "error": error.detail });
    });
});
// Get one passeport from site and year
exports.passeportsRoutes.get("/passeport/:tracabilite/:year", async (req, res) => {
    if (isNaN(+req.params.tracabilite)) {
        return await (0, db_1.executeSql)(`SELECT * FROM passeports WHERE UPPER(site) = '${req.params.tracabilite.toUpperCase()}' AND annee = '${req.params.year}'`)
            .then((passeport) => {
            return passeport.length === 1
                ? res.status(200).json(passeport[0])
                : res.status(404).json({ "code": 404, "error": "Not Found" });
        }).catch(error => {
            console.error(error);
            return res.status(404).json({ "error": error.detail });
        });
    }
    else {
        return await (0, db_1.executeSql)(`SELECT * FROM passeports WHERE annee = '${req.params.year}' AND tracabilite = '${+req.params.tracabilite}'`).then((passeport) => {
            return passeport.length > 0
                ? res.status(200).json(passeport[0])
                : res.status(404).json({ "code": 404, "error": "Not Found" });
        }).catch(error => {
            console.error(error);
            return res.status(404).json({ "error": error.detail });
        });
    }
});
// Create one passeport
exports.passeportsRoutes.post("/passeport", async (req, res) => {
    const values = (0, controller_1.verifyBody)(req.body);
    if (values) {
        return await (0, controller_2.addPasseport)(values)
            .then((passeport) => {
            return res.status(201).json(passeport[0]);
        }).catch(error => {
            console.error(error);
            return res.status(error.code === 23505 ? 409 : 404).json({ "error": error.detail });
        });
    }
    else
        res.status(400).json({ "code": 400, "error": "Bad Request" });
});
// Update one passeport
exports.passeportsRoutes.patch("/passeport/:id", async (req, res) => {
    return await (0, controller_2.updatePasseport)(req.body, +req.params.id)
        .then((passeport) => {
        return res.status(201).json(passeport);
    }).catch(error => {
        console.error(error);
        return res.status(404).json({ "error": error.detail });
    });
});
// delete one passeport
exports.passeportsRoutes.delete("/passeport/:id", async (req, res) => {
    return await (0, controller_1.deleteId)("passeports", +req.params.id)
        .then(() => {
        return res.status(203).json();
    }).catch(error => {
        console.error(error);
        return res.status(404).json({ "error": error.detail });
    });
});
