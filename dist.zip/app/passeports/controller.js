"use strict";
/**
 * Passeports controller
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.addPasseport = addPasseport;
exports.updatePasseport = updatePasseport;
const controller_1 = require("../../controller");
const db_1 = require("../../db");
const base_1 = require("../../db/base");
async function addPasseport(values) {
    return (0, db_1.executeSql)(`SELECT max(tracabilite) FROM ${base_1.dataBase.passeports.name} WHERE annee = '${values["annee"]}'`).then(async (res) => {
        const tmp = res[0]["max"];
        values["tracabilite"] = isNaN(+tmp) ? 1 : +tmp + 1;
        return await (0, db_1.executeSql)(`INSERT INTO ${base_1.dataBase.passeports.name} (${(0, db_1.createPgColumns)(base_1.dataBase.passeports.name, values)}) VALUES (${(0, db_1.createPgValues)(base_1.dataBase.passeports.name, values)}) RETURNING id`);
    });
}
;
async function updatePasseport(values, id) {
    const cols = (0, db_1.getColumns)(base_1.dataBase.passeports.name);
    const datas = cols.filter(e => values[e]);
    return await (0, db_1.executeSql)(`UPDATE ${base_1.dataBase.passeports.name} SET ${datas.map(e => `"${e}" = '${values[e]}'`).join()} WHERE id = ${id}`)
        .then(async () => await (0, controller_1.readId)(base_1.dataBase.passeports.name, id));
}
;
