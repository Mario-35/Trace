"use strict";
/**
 * Passeports controller
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.addPasseport = addPasseport;
exports.updatePasseport = updatePasseport;
const db_1 = require("../../db");
async function addPasseport(values) {
    return (0, db_1.executeSql)(`SELECT max(tracabilite) FROM passeports WHERE annee = '${values["annee"]}'`).then(async (res) => {
        const tmp = res[0]["max"];
        values["tracabilite"] = isNaN(+tmp) ? 1 : +tmp + 1;
        return await (0, db_1.executeSql)(`INSERT INTO passeports (${(0, db_1.createPgColumns)("passeports", values)}) VALUES (${(0, db_1.createPgValues)("passeports", values)}) RETURNING id`);
    });
}
;
async function updatePasseport(values, id) {
    const cols = (0, db_1.getColumns)("passeports");
    const datas = cols.filter(e => values[e]);
    return await (0, db_1.executeSql)(`UPDATE passeports SET ${datas.map(e => `"${e}" = '${values[e]}'`).join()} WHERE id = ${id}`)
        .then(async () => await (0, db_1.executeSql)(`SELECT * FROM passeports WHERE id = ${id}`));
}
;
