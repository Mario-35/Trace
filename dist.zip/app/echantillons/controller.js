"use strict";
/**
 * Echantillons controller
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.addEchantillon = addEchantillon;
exports.updateEchantillon = updateEchantillon;
const controller_1 = require("../../controller");
const db_1 = require("../../db");
const base_1 = require("../../db/base");
const asyncForEach_1 = require("../../helpers/asyncForEach");
async function addEchantillon(values) {
    // store all queries
    const queries = [];
    // store analyzes case nombreOuAnalyses is true
    let analyzes = [];
    // store identification for return request
    let tmpCode = undefined;
    // Create list of columns
    const tableColumns = Object.keys(base_1.dataBase.echantillons.columns).filter(e => values[e]);
    // Create list insert into
    const insertInto = tableColumns;
    // Get the start number
    let start = +values["numero"];
    const codesIdentification = [];
    // Get the nb of lines to insert
    let nb = +values["nombre"];
    // loop on analyses
    if (!values["nombreOuAnalyses"]) {
        analyzes = values["analyses"].split(",");
        nb = analyzes.length;
    }
    // create start string for identification
    tmpCode = values["identification"].slice(0, 12);
    // alicotage insert
    if (values["parent"]) {
        start = values["numero"] ? +values["numero"] : 0;
        // get all ids of the selection
        await (0, controller_1.readId)(base_1.dataBase.selections.name, +values["selectionaliquote"])
            .then(async (ids) => {
            // loop ano all ids
            await (0, asyncForEach_1.asyncForEach)(ids[0].ids, async (id) => {
                await (0, controller_1.readId)(base_1.dataBase.echantillons.name, +id).then((echantillon) => {
                    echantillon = echantillon[0];
                    echantillon["parent"] = echantillon["identification"];
                    echantillon["creation"] = values["creation"];
                    echantillon["etiquette"] = values["etiquette"];
                    for (let loop = 0; loop < nb; loop++) {
                        start = start + 1;
                        const identification = tmpCode + String(start).padStart(4, '0');
                        codesIdentification.push(identification);
                        echantillon["identification"] = identification;
                        echantillon["analyses"] = analyzes[loop];
                        queries.push(`INSERT INTO ${base_1.dataBase.echantillons.name} (${insertInto.join()}) VALUES (${(0, db_1.createPgValues)(base_1.dataBase.echantillons.name, echantillon)})`);
                    }
                });
            });
        }).catch(error => {
            console.error(error);
            return;
        });
    } // If excel insert
    else if (values["excel"]) {
        // get the excel file saved
        await (0, controller_1.readId)(base_1.dataBase.excels.name, +values["excel"]).then((excelFile) => {
            // Create list of excel columns
            const excelCols = excelFile[0]["datas"]["columns"];
            // lopp excel lines
            Object.values(excelFile[0]["datas"]["datas"]).forEach((tmp, index) => {
                // clone line
                const tempVal = JSON.parse(JSON.stringify(values));
                // modify the lines with excel values
                Object.keys(excelCols).forEach(key => {
                    delete tempVal[key];
                    tempVal[key] = tmp[excelCols[key]]; // TODO CHANGE VALUES
                });
                // create identification
                if (tempVal["identification"])
                    tempVal["identification"] = values["identification"].slice(0, 12) + String(+tmp[excelCols["echantillon"]] || index + start).padStart(4, '0');
                if (!tmpCode)
                    tmpCode = values["identification"].slice(0, 12);
                // Go
                queries.push(`INSERT INTO ${base_1.dataBase.echantillons.name} (${insertInto.map(e => `"${e}"`).join()}) VALUES (${(0, db_1.createPgValues)(base_1.dataBase.echantillons.name, tempVal, insertInto)})`);
            });
        }).catch(error => {
            console.error(error);
        });
    } // normal insert
    else {
        // create identification codes
        for (var i = 0; i < nb; i++)
            codesIdentification.push(tmpCode + String(i + start).padStart(4, '0'));
        // loop in identifications
        codesIdentification.forEach((identification, i) => {
            values["identification"] = identification;
            if (!values["nombreOuAnalyses"])
                values["analyses"] = analyzes[i];
            queries.push(`INSERT INTO ${base_1.dataBase.echantillons.name} (${insertInto.join()}) VALUES (${(0, db_1.createPgValues)(base_1.dataBase.echantillons.name, values)})`);
        });
        // execute all queries
        return new Promise(async function (resolve, reject) {
            return (0, db_1.executeSql)(queries).then(async () => {
                // create selection return (usefull for print stickers)
                const selectionId = await db_1.sql.unsafe(`INSERT INTO ${base_1.dataBase.selections.name} (ids) SELECT ARRAY_AGG(id) FROM ${base_1.dataBase.echantillons.name} WHERE identification IN ('${codesIdentification.join("','")}') RETURNING id`);
                resolve({ selection: selectionId[0].id });
            }).catch(error => {
                console.error(error);
                reject(error);
            });
        });
    }
    // execute all queries
    return new Promise(async function (resolve, reject) {
        return await (0, db_1.executeSql)(queries)
            .then(async () => {
            resolve({ identification: tmpCode });
        }).catch(error => {
            console.error(error);
            reject(error);
        });
    });
}
;
async function updateEchantillon(values, id) {
    return new Promise(async function (resolve, reject) {
        return await (0, db_1.executeSql)(`UPDATE ${base_1.dataBase.echantillons.name} SET ${(0, db_1.createPgUpdates)(base_1.dataBase.echantillons.name, values)} WHERE id = ${id}`)
            .then(async () => {
            const ret = await (0, controller_1.readId)(base_1.dataBase.echantillons.name, id);
            resolve(ret);
        }).catch(error => {
            console.error(error);
            reject(error);
        });
    });
}
;
