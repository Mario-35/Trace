"use strict";
/**
 * Samples routes
 *
 * @copyright 2026-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.echantillonsRoutes = void 0;
const express_1 = require("express");
const controller_1 = require("../../controller");
const db_1 = require("../../db");
const controller_2 = require("./controller");
const base_1 = require("../../db/base");
exports.echantillonsRoutes = (0, express_1.Router)();
// Get samples list for UI
exports.echantillonsRoutes.get("/list/" + base_1.dataBase.echantillons.name, async (req, res) => {
    await (0, db_1.executeSql)(`SELECT id, ${(0, db_1.getListColumns)(base_1.dataBase.echantillons.name)} FROM ${base_1.dataBase.echantillons.name} ORDER BY creation`)
        .then((site) => {
        return res.status(200).json(site);
    }).catch(error => {
        return res.status(404).json({ "error": error.detail });
    });
});
// Get one sample from identification
exports.echantillonsRoutes.get("/" + base_1.dataBase.echantillons.singular + "/identification/:id", async (req, res) => {
    await (0, db_1.executeSql)(`SELECT id, ${(0, db_1.getListColumns)(base_1.dataBase.echantillons.name)} FROM ${base_1.dataBase.echantillons.name} WHERE identification ${req.params.id.length < 13 ? 'LIKE' : '='} '${req.params.id}${req.params.id.length < 13 ? '%' : ''}' ORDER BY identification`)
        .then((echantillon) => {
        return res.status(200).json(echantillon);
    }).catch(error => {
        return res.status(404).json({ "error": error.detail });
    });
});
// Get all samples series from one echantillons
exports.echantillonsRoutes.get("/" + base_1.dataBase.echantillons.name + "/serie/:id", async (req, res) => {
    await (0, db_1.executeSql)(`SELECT id FROM ${base_1.dataBase.echantillons.name} WHERE identification LIKE CONCAT((SELECT SUBSTRING ( identification FROM 1 FOR 12 ) FROM ${base_1.dataBase.echantillons.name} WHERE id =${req.params.id}), '%') GROUP BY id ORDER by id`)
        .then((echantillon) => {
        return res.status(200).json(echantillon);
    }).catch(error => {
        return res.status(404).json({ "error": error.detail });
    });
});
// Get all samples
exports.echantillonsRoutes.get("/" + base_1.dataBase.echantillons.name, async (req, res) => {
    return await (0, db_1.executeSql)(`SELECT * FROM ${base_1.dataBase.echantillons.name} ORDER BY creation, Identification`)
        .then((echantillons) => {
        return res.status(200).json(echantillons);
    }).catch(error => {
        return res.status(404).json({ "error": error.detail });
    });
});
// Get samples From passport id
exports.echantillonsRoutes.get("/list/" + base_1.dataBase.echantillons.name + "/:id", async (req, res) => {
    await (0, db_1.executeSql)(`SELECT id, ${(0, db_1.getListColumns)(base_1.dataBase.echantillons.name)} FROM ${base_1.dataBase.echantillons.name} WHERE passeport = ${+req.params.id} ORDER BY creation`)
        .then((echantillons) => {
        return res.status(200).json(echantillons);
    }).catch(error => {
        return res.status(404).json({ "error": error.detail });
    });
});
// Get one sample
exports.echantillonsRoutes.get("/" + base_1.dataBase.echantillons.singular + "/:id", async (req, res) => {
    return await (0, controller_1.readId)(base_1.dataBase.echantillons.name, +req.params.id)
        .then(async (echantillon) => {
        if (echantillon.length === 1) {
            echantillon = echantillon[0];
            if (Object.keys(echantillon.cultures).length > 0) {
                echantillon.codes = await (0, db_1.executeSqlValues)(`SELECT CONCAT('"', UPPER(code), '" : "',valeur, '"') FROM rpg WHERE UPPER(code) IN ('${Array.from(new Set(Object.values(echantillon.cultures).map(item => item))).join("','")}')`);
            }
            return res.status(200).json(echantillon);
        }
        else
            return res.status(404).json({ "error": "Not found" });
    }).catch(error => {
        return res.status(404).json({ "error": error.detail });
    });
});
// Get next sample number
exports.echantillonsRoutes.get("/" + base_1.dataBase.echantillons.singular + "/next/identification/:id", async (req, res) => {
    return await (0, db_1.executeSql)(`SELECT COALESCE( MAX( SUBSTRING ( identification FROM 13 FOR 4 ):: int ), 0) as numero FROM ${base_1.dataBase.echantillons.name} WHERE identification LIKE '${String(req.params.id.slice(0, 12))}%' LIMIT 1`)
        .then((max) => {
        return res.status(200).json({ max: Number(max[0].max) + 1 });
    }).catch(error => {
        return res.status(404).json({ "error": error.detail });
    });
});
// Get next sample number for after request
exports.echantillonsRoutes.get("/" + base_1.dataBase.echantillons.singular + "/after/identification/:id", async (req, res) => {
    return await (0, db_1.executeSql)(`SELECT MAX( SUBSTRING ( identification FROM 13 FOR 4 ):: int ) FROM ${base_1.dataBase.echantillons.name} WHERE identification like CONCAT( ( SELECT SUBSTRING ( identification FROM 1 FOR 12 ) FROM ${base_1.dataBase.echantillons.name} WHERE id = ${+String(req.params.id)} ), '%' )`)
        .then((max) => {
        return res.status(200).json({ max: Number(max[0].max) + 1 });
    }).catch(error => {
        return res.status(404).json({ "error": error.detail });
    });
});
// Create one sample
exports.echantillonsRoutes.post("/" + base_1.dataBase.echantillons.singular + "", async (req, res) => {
    await (0, controller_2.addEchantillon)(req.body)
        .then((echantillon) => {
        return res.status(201).json(echantillon);
    }).catch(error => {
        return res.status(error.code === 23505 ? 409 : 404).json({ "error": error.detail });
    });
});
// Update one sample
exports.echantillonsRoutes.patch("/" + base_1.dataBase.echantillons.singular + "/:id", async (req, res) => {
    await (0, controller_2.updateEchantillon)(req.body, +req.params.id)
        .then((echantillon) => {
        return res.status(201).json(echantillon);
    }).catch((error) => {
        return res.status(404).json({ "error": error.detail });
    });
});
// Update Selection
exports.echantillonsRoutes.patch("/" + base_1.dataBase.echantillons.name + "/selection/:id", async (req, res) => {
    return await (0, db_1.executeSql)(`SELECT ids FROM selections WHERE id=${+req.params.id}`)
        .then(async (ids) => {
        return await (0, db_1.executeSql)(`UPDATE ${base_1.dataBase.echantillons.name} SET ${(0, db_1.createPgUpdates)(base_1.dataBase.echantillons.name, req.body)} WHERE id IN (${ids[0].ids})`)
            .then(() => {
            return res.status(201).json({ selection: +req.params.id });
        }).catch((error) => {
            return res.status(404).json({ "error": error.detail });
        });
    }).catch(error => {
        return res.status(404).json({ "error": error.detail });
    });
});
// delete one sample
exports.echantillonsRoutes.delete("/" + base_1.dataBase.echantillons.singular + "/:id", async (req, res) => {
    return await (0, controller_1.deleteId)(base_1.dataBase.echantillons.name, +req.params.id)
        .then(() => {
        return res.status(203).json();
    }).catch(error => {
        return res.status(404).json({ "error": error.detail });
    });
});
