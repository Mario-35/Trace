"use strict";
/**
 * Echantillons routes
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.echantillonsRoutes = void 0;
const express_1 = require("express");
const controller_1 = require("../../controller");
const db_1 = require("../../db");
const controller_2 = require("./controller");
exports.echantillonsRoutes = (0, express_1.Router)();
exports.echantillonsRoutes.get("/list/echantillons", async (req, res) => {
    await (0, db_1.executeSql)(`SELECT id, ${(0, db_1.createListColumns)("echantillons")} FROM echantillons ORDER BY creation`)
        .then((site) => {
        return res.status(200).json(site);
    }).catch(error => {
        return res.status(404).json({ "error": error.detail });
    });
});
// Get one echantillon from identification
exports.echantillonsRoutes.get("/echantillon/identification/:id", async (req, res) => {
    await (0, db_1.executeSql)(`SELECT id, ${(0, db_1.createListColumns)("echantillons")} FROM echantillons WHERE identification ${req.params.id.length < 13 ? 'LIKE' : '='} '${req.params.id}${req.params.id.length < 13 ? '%' : ''}' ORDER BY creation`)
        .then((echantillon) => {
        return res.status(200).json(echantillon);
    }).catch(error => {
        return res.status(404).json({ "error": error.detail });
    });
});
// Get all echantillons
exports.echantillonsRoutes.get("/echantillons", async (req, res) => {
    return await (0, db_1.executeSql)(`SELECT * FROM echantillons ORDER BY creation, Identification`)
        .then((echantillons) => {
        return res.status(200).json(echantillons);
    }).catch(error => {
        return res.status(404).json({ "error": error.detail });
    });
});
// Get all echantillons with passport id
exports.echantillonsRoutes.get("/list/echantillons/:id", async (req, res) => {
    await (0, db_1.executeSql)(`SELECT id, ${(0, db_1.createListColumns)("echantillons")} FROM echantillons WHERE passeport = ${+req.params.id} ORDER BY creation`)
        .then((echantillons) => {
        return res.status(200).json(echantillons);
    }).catch(error => {
        return res.status(404).json({ "error": error.detail });
    });
});
// Get one sample
exports.echantillonsRoutes.get("/echantillon/:id", async (req, res) => {
    return await (0, controller_1.readId)("echantillons", +req.params.id)
        .then(async (echantillon) => {
        if (echantillon.length === 1) {
            echantillon = echantillon[0];
            if (Object.keys(echantillon.cultures).length > 0) {
                echantillon.codes = await (0, db_1.executeSqlValues)(`SELECT CONCAT('"', UPPER(code), '" : "',valeur, '"') FROM rpg WHERE UPPER(code) IN ('${Array.from(new Set(Object.values(echantillon.cultures).map(item => item))).join("','")}')`);
            }
            return res.status(200).json(echantillon);
        }
        else
            return res.status(404).json({ "error": "Not found" });
    }).catch(error => {
        return res.status(404).json({ "error": error.detail });
    });
});
// Get next sample number
exports.echantillonsRoutes.get("/echantillon/next/:id", async (req, res) => {
    return await (0, db_1.executeSql)(`SELECT MAX(SUBSTRING (identification FROM 13 FOR 4)::int) from echantillons where identification LIKE '${req.params.id.slice(0, 12)}%'`)
        .then((max) => {
        return res.status(200).json(Number(max[0].max) + 1);
    }).catch(error => {
        return res.status(404).json({ "error": error.detail });
    });
});
// Get next sample number for after request
exports.echantillonsRoutes.get("/echantillon/after/:id", async (req, res) => {
    return await (0, db_1.executeSql)(`select MAX(SUBSTRING (identification FROM 13 FOR 4)::int) from echantillons where identification like CONCAT((select SUBSTRING (identification FROM 1 FOR 12) from echantillons where id = ${+req.params.id}), '%')`)
        .then((max) => {
        return res.status(200).json(Number(max[0].max) + 1);
    }).catch(error => {
        return res.status(404).json({ "error": error.detail });
    });
});
// Create one sample
exports.echantillonsRoutes.post("/echantillon", async (req, res) => {
    await (0, controller_2.addEchantillon)(req.body)
        .then((echantillon) => {
        return res.status(201).json(echantillon);
    }).catch(error => {
        return res.status(error.code === 23505 ? 409 : 404).json({ "error": error.detail });
    });
});
// Update one sample
exports.echantillonsRoutes.patch("/echantillon/:id", async (req, res) => {
    await (0, controller_2.updateEchantillon)(req.body, +req.params.id)
        .then((echantillon) => {
        return res.status(201).json(echantillon);
    }).catch((error) => {
        return res.status(404).json({ "error": error.detail });
    });
});
// delete one sample
exports.echantillonsRoutes.delete("/echantillon/:id", async (req, res) => {
    return await (0, controller_1.deleteId)("echantillons", +req.params.id)
        .then(() => {
        return res.status(203).json();
    }).catch(error => {
        return res.status(404).json({ "error": error.detail });
    });
});
