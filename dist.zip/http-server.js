"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const cors_1 = __importDefault(require("cors"));
const helmet_1 = __importDefault(require("helmet"));
const multer_1 = __importDefault(require("multer"));
const compression_1 = __importDefault(require("compression"));
const path_1 = __importDefault(require("path"));
const logger_1 = require("./infra/logger");
const db_1 = require("./db");
;
const app_1 = require("./app");
const routes_1 = require("./app/configuration/routes");
class HttpServer {
    app;
    storage;
    upload;
    _datas;
    constructor(app) {
        this.app = app;
        this.storage = multer_1.default.memoryStorage();
        this.upload = (0, multer_1.default)({ storage: this.storage });
    }
    async createApp() {
        this.loadMiddlewares();
        this.loadRoutes();
        return this.app;
    }
    async stop() {
        logger_1.logger.info("Arret..");
    }
    loadMiddlewares() {
        this.app.use((0, cors_1.default)());
        this.app.use((0, helmet_1.default)({
            contentSecurityPolicy: false,
            xDownloadOptions: false,
        }));
        this.app.use(express_1.default.json({ limit: '50mb' }));
        this.app.use(express_1.default.static(path_1.default.join(__dirname, 'public')));
        this.app.use(express_1.default.json());
        this.app.use(express_1.default.urlencoded({ extended: true }));
        this.app.use((0, compression_1.default)());
    }
    loadRoutes() {
        this.app.use('/', routes_1.configRoutes);
        this.app.use('/', app_1.echantillonsRoutes);
        this.app.use('/', app_1.passeportsRoutes);
        this.app.use('/', app_1.sitesRoutes);
        this.app.use('/', app_1.pagesRoutes);
        this.app.use('/', app_1.excelsRoutes);
        this.app.use('/', app_1.selectionsRoutes);
        this.app.use('/', app_1.campagnesRoutes);
        this.app.use('/', app_1.evenementsRoutes);
        this.app.use('/', app_1.rpgsRoutes);
        this.app.get("/", async (_req, res) => {
            res.json({
                message: "Serveur actif...",
            });
        });
        // Get test
        this.app.get("/init/:password", async (_req, res) => {
            res.status(200).json(await (0, db_1.createDB)(_req.params["password"]));
        });
        this.app.get("/export", async (_req, res) => {
            res.status(200).json(await (0, db_1.writeDB)());
        });
        this.app.get("/test", async (_req, res) => {
            const lines = [];
            let ech = 0;
            for (let step = 1; step < 43; step++) {
                const nbParcelle = String(step).padStart(2, '0');
                ["Stabilitée", "Densités apparentes", "Composite 1", "Composite 2", "Composite 3", "Composite 4", "Feuille Blé",].forEach((e) => {
                    ech = ech + 1;
                    const nbEch = String(ech).padStart(2, '0');
                    lines.push(` { "type": "Sol", "programme": "Thése Michael Briere", "caracterisation": "Normal", "condition": null, "site": "Parcelle F0${nbParcelle}", "responsable": "S. Menasseri", "identification": "19032026114400${nbEch}", "parent": null, "dossier": "440", "libre": null, "creation": "2026-03-19T10:44:30.668", "prelevement": "2026-04-07", "peremption": "2031-04-07", "pays": "France", "region": "Bretagne", "latitude": "48.03169", "longitude": "-1.53286", "passeport": null, "cultures": {}, "stockage": {}, "etiquette": { "sticker0": { "key": "identification", "size": "12px", "align": "center" }, "sticker1": { "key": "programme", "size": "12px", "align": "center" }, "sticker2": { "key": "dossier-numero", "size": "14px", "align": "center" }, "sticker3": { "key": "responsable", "size": "12px", "align": "center" }, "sticker4": { "key": "pays", "size": "12px", "align": "center" }, "sticker5": { "key": "analyses", "size": "12px", "align": "center" } }, "analyses": [ "${e}" ], "etat": "Créer" }, `);
                });
            }
            res.status(200).json({});
        });
        // ########################################################
        // #                        FILES                         #
        // ########################################################
        // Route to upload an image
        this.app.post('/upload', this.upload.single('image'), async (_req, res) => {
            if (_req.file)
                try {
                    const imageBuffer = _req.file.buffer;
                    const filename = _req.file.originalname;
                    const result = await db_1.sql.unsafe('INSERT INTO fichiers (fichier, nom) VALUES ($1, $2) RETURNING id', [imageBuffer, filename]);
                    res.json(result[0]);
                }
                catch (err) {
                    console.error(err);
                    res.status(500).send('Error uploading file');
                }
        });
        this.app.get("/download/:id", async (_req, res) => {
            return await await db_1.sql.unsafe(`SELECT fichier FROM fichiers WHERE id = ${+_req.params.id}`).then((fichier) => {
                return res.status(200).json(fichier);
            }).catch(error => {
                return res.status(404).json({ "error": error.detail });
            });
        });
        // return the status server
        this.app.get("/status", async (_req, res) => {
            res.status(200).json({
                status: "Serveur actif",
                timestamp: new Date().toLocaleString(),
                uptime: process.uptime()
            });
        });
        this.app.use((req, res) => {
            res.status(404).json({
                error: {
                    code: "ENDPOINT_NOT_FOUND",
                    message: "Endpoint not found",
                    path: req.originalUrl,
                }
            });
        });
    }
}
exports.default = HttpServer;
