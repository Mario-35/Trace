"use strict";
/**
 * Controllers
 *
 * @copyright 2026-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.readAll = readAll;
exports.readAlSearch = readAlSearch;
exports.readId = readId;
exports.readIds = readIds;
exports.verifyBody = verifyBody;
exports.deleteId = deleteId;
const db_1 = require("../db");
const base_1 = require("../db/base");
async function readAll(table) {
    return await (0, db_1.executeSql)(`SELECT * FROM "${table}"`);
}
;
async function readAlSearch(table, search) {
    const tableColumns = Object.keys(base_1.dataBase[table]["columns"]);
    return await (0, db_1.executeSql)(`SELECT * FROM "${table}" WHERE ${tableColumns.map(e => `"${e}" LIKE '%${search}%'`).join(" OR ")}`);
}
;
async function readId(table, id) {
    return await (0, db_1.executeSql)(`SELECT * FROM "${table}" WHERE id = ${id}`);
}
;
async function readIds(table, ids) {
    return await (0, db_1.executeSql)(`SELECT * FROM "${table}" WHERE id IN (${ids.join()})`);
}
;
function verifyBody(values) {
    try {
        if (!values)
            return undefined;
        if (Object.keys(values).length < 1)
            return undefined;
    }
    catch (error) {
        console.error(error);
        return undefined;
    }
    return values;
}
async function deleteId(table, id) {
    return await (0, db_1.executeSql)(`DELETE FROM ${(0, db_1.sql)(table)} WHERE id = ${id}`);
}
;
