"use strict";
/**
 * DB index
 *
 * @copyright 2020-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.writeDB = exports.createPgUpdate = exports.createPgInsert = exports.createListColumns = exports.createPgColumns = exports.createPgUpdates = exports.createPgValues = exports.createDetaultDatas = exports.createDB = exports.executeSqlValues = exports.executeSql = exports.getColumns = exports.sql = void 0;
exports.admin = admin;
exports.addPartiton = addPartiton;
exports.isDbExists = isDbExists;
const postgres_1 = __importDefault(require("postgres"));
const base_1 = require("./base");
const executeSql_1 = require("./executeSql");
const pwd = process.env.NODE_ENV === 'production' ? 'postgres' : "postgres";
exports.sql = (0, postgres_1.default)('postgres://postgres:' + pwd + '@localhost:5432/trace', {
    host: 'localhost', // Postgres ip address[s] or domain name[s]
    port: 5432, // Postgres server port[s]
    database: 'trace', // Name of database to connect to
    username: 'postgres', // Username of database user
    password: pwd, // Password of database user
    debug: true,
    max: 2000,
    connection: {
        application_name: `Echantillons`
    }
});
function admin(password) {
    return (0, postgres_1.default)(`postgres://postgres:${password}@localhost:5432/postgres`, {
        host: 'localhost', // Postgres ip address[s] or domain name[s]
        port: 5432, // Postgres server port[s]
        database: 'postgres', // Name of database to connect to
        username: 'postgres', // Username of database user
        password: password, // Password of database user
        debug: true,
        max: 2000,
        connection: {
            application_name: `Trace`
        }
    });
}
const getColumns = (tableName) => Object.keys(base_1.dataBase[tableName].columns).filter(e => e != "id");
exports.getColumns = getColumns;
function addPartiton(name) {
    (0, executeSql_1.executeSql)(`CREATE TABLE IF NOT EXISTS "echantillon_${name.toLowerCase()}" PARTITION OF echantillons FOR VALUES IN ('${name}');`);
}
async function isDbExists() {
    return await exports.sql
        .unsafe(`select 1+1 AS result`)
        .then(() => {
        return true;
    })
        .catch((error) => {
        console.error(error);
        return false;
    });
}
var executeSql_2 = require("./executeSql");
Object.defineProperty(exports, "executeSql", { enumerable: true, get: function () { return executeSql_2.executeSql; } });
var executeSqlValues_1 = require("./executeSqlValues");
Object.defineProperty(exports, "executeSqlValues", { enumerable: true, get: function () { return executeSqlValues_1.executeSqlValues; } });
var createDB_1 = require("./createDB");
Object.defineProperty(exports, "createDB", { enumerable: true, get: function () { return createDB_1.createDB; } });
var createDetaultDatas_1 = require("./createDetaultDatas");
Object.defineProperty(exports, "createDetaultDatas", { enumerable: true, get: function () { return createDetaultDatas_1.createDetaultDatas; } });
var createPgValues_1 = require("./createPgValues");
Object.defineProperty(exports, "createPgValues", { enumerable: true, get: function () { return createPgValues_1.createPgValues; } });
var createPgUpdates_1 = require("./createPgUpdates");
Object.defineProperty(exports, "createPgUpdates", { enumerable: true, get: function () { return createPgUpdates_1.createPgUpdates; } });
var createPgColumns_1 = require("./createPgColumns");
Object.defineProperty(exports, "createPgColumns", { enumerable: true, get: function () { return createPgColumns_1.createPgColumns; } });
var createListColumns_1 = require("./createListColumns");
Object.defineProperty(exports, "createListColumns", { enumerable: true, get: function () { return createListColumns_1.createListColumns; } });
var createPgInsert_1 = require("./createPgInsert");
Object.defineProperty(exports, "createPgInsert", { enumerable: true, get: function () { return createPgInsert_1.createPgInsert; } });
var createPgUpdate_1 = require("./createPgUpdate");
Object.defineProperty(exports, "createPgUpdate", { enumerable: true, get: function () { return createPgUpdate_1.createPgUpdate; } });
var writeDB_1 = require("./writeDB");
Object.defineProperty(exports, "writeDB", { enumerable: true, get: function () { return writeDB_1.writeDB; } });
