"use strict";
/**
 * Execute SQL(s) values
 *
 * @copyright 2026-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.executeSqlValues = void 0;
const _1 = require(".");
const executeSqlOneValues = async (query) => {
    return new Promise(async function (resolve, reject) {
        await _1.sql
            .unsafe(query)
            .values()
            .then((res) => {
            resolve(res);
        })
            .catch((error) => {
            console.error(error);
            reject(error);
        });
    });
};
const executeSqlMultiValues = async (queries) => {
    return new Promise(async function (resolve, reject) {
        await _1.sql
            .begin((sql) => queries.map(async (query) => {
            await sql.unsafe(query).values();
        }))
            .then((res) => {
            resolve(res);
        })
            .catch((error) => {
            console.error(error);
            reject(error);
        });
    });
};
const executeSqlValues = async (query) => typeof query === "string" ? executeSqlOneValues(query) : executeSqlMultiValues(query);
exports.executeSqlValues = executeSqlValues;
