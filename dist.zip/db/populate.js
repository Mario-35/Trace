"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.populate = populate;
const path_1 = __importDefault(require("path"));
const asyncForEach_1 = require("../helpers/asyncForEach");
const base_1 = require("./base");
const executeSql_1 = require("./executeSql");
const fs_1 = require("fs");
const _1 = require(".");
async function populate() {
    (0, asyncForEach_1.asyncForEach)(Object.keys(base_1.dataBase).filter(e => e !== "fichiers"), async (tableName) => {
        if (base_1.dataBase[tableName].save === true) {
            const file = (0, fs_1.readFileSync)(path_1.default.join(__dirname, "../import", tableName + '.json'), 'utf-8');
            const datas = JSON.parse(file);
            const queries = [];
            Object(datas[tableName]).forEach((data) => {
                delete data["id"];
                queries.push(`INSERT INTO ${tableName} (${(0, _1.createPgColumns)(tableName, data)}) VALUES (${(0, _1.createPgValues)(tableName, data)})`);
            });
            (0, executeSql_1.executeSql)(queries).catch((error) => {
                console.error(error);
                return false;
            });
        }
    });
    return true;
}
