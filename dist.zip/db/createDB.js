"use strict";
/**
 * Create DB
 *
 * @copyright 2026-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.createDB = createDB;
const _1 = require(".");
const base_1 = require("./base");
const asyncForEach_1 = require("../helpers/asyncForEach");
const populate_1 = require("./populate");
const constant_1 = require("../constant");
const toTitleCase_1 = require("../helpers/toTitleCase");
/**
 *
 * @param adminPass postgres admin password
 * @returns JSON infos
 */
async function createDB(adminPass) {
    // JSON result
    const result = {};
    // kill all process api
    const create = await (0, _1.admin)(adminPass)
        .unsafe("SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE pid <> pg_backend_pid() AND datname = 'trace';")
        .then(async (res) => {
        // drop database
        return await (0, _1.admin)(adminPass)
            .unsafe("DROP DATABASE trace")
            .then(async () => {
            result["DROP DATABASE"] = "Ok";
            // create blank database
            return await (0, _1.admin)(adminPass)
                .unsafe("CREATE DATABASE trace")
                .then(async (res) => {
                result["CREATE DATABASE"] = "Ok";
                return true;
            })
                .catch((error) => {
                console.log(error);
                result["CREATE DATABASE"] = "Error";
                return false;
            });
        })
            .catch(async (error) => {
            console.log(error);
            return await (0, _1.admin)(adminPass)
                .unsafe("CREATE DATABASE trace")
                .then(async (res) => {
                result["CREATE DATABASE"] = "Ok";
                return true;
            })
                .catch((error) => {
                console.log(error);
                result["CREATE DATABASE"] = "Error";
                return false;
            });
        });
    });
    // if crete database false exit
    if (create === false)
        return result;
    // store all queries
    const queries = ["CREATE EXTENSION unaccent;"];
    // loop on tables
    Object.keys(base_1.dataBase).forEach((tableName) => {
        // store posgresSql column create syntax
        const pgCols = [];
        // can create
        if (base_1.dataBase[tableName].create === true) {
            // loop on columns
            Object.keys(base_1.dataBase[tableName].columns).forEach((columnName) => {
                if (String(base_1.dataBase[tableName].columns[columnName]["create"]).trim() !== "")
                    pgCols.push(columnName +
                        " " +
                        base_1.dataBase[tableName].columns[columnName]["create"]);
            });
            // loop on constaints
            base_1.dataBase[tableName].constraints.forEach((e) => pgCols.push(e));
            // add to queries
            queries.push(`CREATE TABLE ${tableName} (${pgCols.join()})${tableName === "echantillons" ? " PARTITION BY LIST(type)" : ""};`);
        }
    });
    // Execute queries
    await (0, _1.executeSql)(queries)
        .then(async (res) => {
        result["CREATE Tables"] = "Ok";
    })
        .catch((error) => {
        console.error(error);
        result["CREATE Tables"] = "Error";
    });
    // Loop to create partition tables
    await (0, asyncForEach_1.asyncForEach)(constant_1._TYPES, async (name) => {
        await (0, _1.executeSql)(`CREATE TABLE IF NOT EXISTS "echantillon_${name.replaceAll(" ", "").toLowerCase()}" PARTITION OF echantillons FOR VALUES IN ('${(0, toTitleCase_1.toTitleCase)(name)}');`).then(() => {
            result["CREATE TABLE partitionned " + name] = "Ok";
        });
    });
    // populate tables with datas in import directory
    await (0, populate_1.populate)()
        .then(() => {
        result["Populate Tables"] = "Ok";
    })
        .catch((error) => {
        console.error(error);
        result["Populate Tables"] = "Error";
    });
    return result;
}
