"use strict";
/**
 * Create column list  with postgresSql syntax
 *
 * @copyright 2026-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.createPgColumns = createPgColumns;
const _1 = require(".");
function createPgColumns(tableName, values) {
    return (0, _1.getColumns)(tableName).map(column => values[column] ? `"${column}"` : '').filter(e => e !== "").join();
}
