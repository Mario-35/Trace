"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createEventSql = createEventSql;
function createEventSql(datas) {
    return datas.identification.map((id) => `INSERT INTO public.evenements (date, identification, personne, operation, savestockage, saveetat) VALUES(NOW(), (SELECT identification FROM echantillons WHERE id = '${id}' LIMIT 1)::TEXT, '${datas.personne}', '${datas.operation}', COALESCE((SELECT stockage FROM echantillons WHERE id = '${id}' LIMIT 1)::jsonb, '{}'), (SELECT etat FROM echantillons WHERE id = '${id}' LIMIT 1)::TEXT); `);
}
