"use strict";
/**
 * Create UPDATE statement with postgresSql syntax
 *
 * @copyright 2026-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.createPgUpdates = createPgUpdates;
const _1 = require(".");
const escapeSimpleQuotes_1 = require("../helpers/escapeSimpleQuotes");
const base_1 = require("./base");
function createPgUpdates(tableName, values) {
    const results = [];
    const columns = (0, _1.getColumns)(tableName);
    columns.forEach((column) => {
        if (values[column]) {
            switch (base_1.dataBase[tableName].columns[column].type) {
                case "text":
                    results.push(`"${column}" = '${(0, escapeSimpleQuotes_1.escapeSimpleQuotes)(values[column])}'`);
                    break;
                case "text[]":
                    results.push(`"${column}" = '{"${values[column].split(",").map((str) => (0, escapeSimpleQuotes_1.escapeSimpleQuotes)(str)).join('","')}"}'`);
                    break;
                case "json":
                    results.push(`"${column}" = '${JSON.stringify(values[column])}'`);
                    break;
                default:
                    results.push(`"${column}" = '${values[column]}'`);
            }
        }
    });
    return results.join();
}
