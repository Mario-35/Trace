"use strict";
/**
 * Create INSERT statement with postgresSql syntax
 *
 * @copyright 2026-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.createPgInsert = createPgInsert;
const _1 = require(".");
function createPgInsert(tableName, values) {
    return `INSERT INTO ${tableName} (${(0, _1.createPgColumns)(tableName, values)}) VALUES (${(0, _1.createPgValues)(tableName, values)})`;
}
