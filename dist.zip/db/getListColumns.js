"use strict";
/**
 * Get all column List
 *
 * @copyright 2026-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.getListColumns = getListColumns;
const _1 = require(".");
const base_1 = require("./base");
/**
 *
 * @param tableName Name of database key table
 * @returns all coulum with list true
 */
function getListColumns(tableName) {
    return (0, _1.getColumns)(tableName)
        .filter(column => base_1.dataBase[tableName].columns[column].list === true)
        .map(column => base_1.dataBase[tableName].columns[column].calculate
        ? `${base_1.dataBase[tableName].columns[column].calculate} AS ${column}`
        : `"${column}"`)
        .filter(e => e !== "")
        .join();
}
