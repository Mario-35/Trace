"use strict";
/**
 * Create UPDATE table statement with postgresSql syntax
 *
 * @copyright 2026-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.createPgUpdate = createPgUpdate;
const _1 = require(".");
function createPgUpdate(tableName, values) {
    return `UPDATE ${tableName} SET ${(0, _1.createPgUpdates)(tableName, values)}`;
}
