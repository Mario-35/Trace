"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createPgUpdate = createPgUpdate;
const _1 = require(".");
function createPgUpdate(tableName, values) {
    return `UPDATE ${tableName} SET ${(0, _1.createPgUpdates)(tableName, values)}`;
}
