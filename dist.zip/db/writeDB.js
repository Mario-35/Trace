"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.writeDB = writeDB;
const _1 = require(".");
const asyncForEach_1 = require("../helpers/asyncForEach");
const base_1 = require("./base");
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
async function asJson(tableName) {
    return (0, _1.executeSql)(`SELECT COALESCE( JSON_AGG(t), '[]') AS ${tableName} FROM ( SELECT ${(0, _1.getColumns)(tableName).filter(column => base_1.dataBase[tableName].columns[column].create !== "")} FROM "${tableName}" ) AS t`)
        .then((res) => res)
        .catch((error) => {
        console.error(error);
    });
}
async function writeDB() {
    const result = {};
    (0, asyncForEach_1.asyncForEach)(Object.keys(base_1.dataBase).filter(e => base_1.dataBase[e].create === true), async (tableName) => {
        // if (dataBase[tableName].save === true) {
        const datas = await asJson(tableName);
        result[tableName] = datas[0];
        fs_1.default.writeFile(path_1.default.join(__dirname, "../import", tableName + '.json'), JSON.stringify(datas[0], null, 4), 'utf8', () => {
            console.log(`Data written to ${tableName}'.json' as JSON.`);
        });
        // }
    });
    return { "status": "ok" };
}
// app.use(serve(path.join(__dirname, "/", "public")));
