"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.dumpDB = dumpDB;
exports.writeDB = writeDB;
const _1 = require(".");
const asyncForEach_1 = require("../helpers/asyncForEach");
const base_1 = require("./base");
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
const node_child_process_1 = require("node:child_process");
const node_util_1 = __importDefault(require("node:util"));
// promisify exec
const execPromise = node_util_1.default.promisify(node_child_process_1.exec);
async function asJson(tableName) {
    return (0, _1.executeSql)(`SELECT COALESCE( JSON_AGG(t), '[]') AS ${tableName} FROM ( SELECT ${(0, _1.getColumns)(tableName).filter((column) => base_1.dataBase[tableName].columns[column].create !== "")} FROM "${tableName}" ) AS t`)
        .then((res) => res)
        .catch((error) => {
        console.error(error);
    });
}
function isStdError(err) {
    return !!err.stderr;
}
async function dumpDB(fileName) {
    try {
        await execPromise(`pg_dump --dbname=postgresql://postgres:postgres@localhost:5432/trace -F tar -f ./uploads/${fileName}`);
        return true;
    }
    catch (e) {
        if (isStdError(e)) {
            console.log(e.stderr);
            return false;
        }
        else {
            throw e;
        }
    }
}
async function writeDB() {
    const result = {};
    (0, asyncForEach_1.asyncForEach)(Object.keys(base_1.dataBase).filter((e) => base_1.dataBase[e].create === true), async (tableName) => {
        // if (dataBase[tableName].save === true) {
        const datas = await asJson(tableName);
        result[tableName] = datas[0];
        fs_1.default.writeFile(path_1.default.join(__dirname, "../import", tableName + ".json"), JSON.stringify(datas[0], null, 4), "utf8", () => {
            console.log(`Data written to ${tableName}'.json' as JSON.`);
        });
        // }
    });
    return { status: "ok" };
}
