"use strict";
/**
 * Create list values with postgresSql syntax
 *
 * @copyright 2026-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.createPgValues = createPgValues;
const _1 = require(".");
const escapeSimpleQuotes_1 = require("../helpers/escapeSimpleQuotes");
const toTitleCase_1 = require("../helpers/toTitleCase");
const base_1 = require("./base");
// Create list values with postgresSql syntax
function createPgValues(tableName, values, columns) {
    const results = [];
    (columns || (0, _1.getColumns)(tableName)).forEach((column) => {
        if (values[column] && values[column] !== "") {
            switch (base_1.dataBase[tableName].columns[column].type) {
                case "text[]":
                    typeof values[column] === "string"
                        ? results.push(`{"${values[column].split(",").join('","')}"}`)
                        : results.push(`{"${values[column]}"}`);
                    break;
                case "json":
                    results.push(`${JSON.stringify(values[column])}`);
                    break;
                case "text":
                    results.push((0, escapeSimpleQuotes_1.escapeSimpleQuotes)((0, toTitleCase_1.toTitleCase)(values[column])));
                    break;
                default:
                    results.push((0, escapeSimpleQuotes_1.escapeSimpleQuotes)(values[column]));
            }
        }
    });
    return `'${results.join("','")}'`;
}
