"use strict";
/**
 * Constants
 *
 * @copyright 2026-present Inrae
 * @author mario.adam@inrae.fr
 *
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports._FILTER = exports._CONFIG = exports.EConstant = exports._TYPES = void 0;
exports.setConfig = setConfig;
exports.setFilter = setFilter;
exports._TYPES = ["Boues", "Eau", "Invertébrés", "Sol cultivé", "Sol forestier", "Prairie", "Sol", "Végétal"];
exports.EConstant = Object.freeze({
    appName: "Trace",
    repository: "https://github.com/Mario-35/Trace",
    localHost: "http://localhost:3000",
    branch: "main",
    columnSeparator: "@|@",
    doubleQuotedComa: '",\n"',
    simpleQuotedComa: "',\n'",
    newline: "\r\n",
    tab: "\t",
    return: "\n",
    host: "127.0.0.1",
    pg: "postgres",
    port: 5432,
    voidSql: "SELECT 1=1",
    version: "1.0",
    date: "15-02-2026",
});
exports._CONFIG = {};
function setConfig(input) {
    exports._CONFIG = input;
}
exports._FILTER = undefined;
function setFilter(input) {
    exports._FILTER = input;
}
